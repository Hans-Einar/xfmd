// Package governancemcp exposes the shared process core over local MCP.
// Launch configuration, never tool arguments, owns project and assignment scope.
package governancemcp

import (
	"fmt"
	"strings"
	"unicode/utf8"

	"github.com/Hans-Einar/SDP/SDPTool/governance"
	"github.com/modelcontextprotocol/go-sdk/mcp"
)

const SDKVersion = "v1.8.0"
const ProtocolVersion = "2025-11-25"

func New(service *governance.Service, runID, attemptID, epoch string) (*mcp.Server, error) {
	return newServer(service, runID, attemptID, epoch, "")
}

// NewCoordinator is an explicit launcher capability, never selected by tool input.
// It permits project inspection and report acknowledgement, not owner decisions.
func NewCoordinator(service *governance.Service, coordinator string) (*mcp.Server, error) {
	if strings.TrimSpace(coordinator) == "" || len(coordinator) > 256 || !utf8.ValidString(coordinator) {
		return nil, fmt.Errorf("bounded coordinator identity required")
	}
	return newServer(service, "", "", "", coordinator)
}
func newServer(service *governance.Service, runID, attemptID, epoch, coordinator string) (*mcp.Server, error) {
	if service == nil {
		return nil, fmt.Errorf("missing governance service")
	}
	var caller governance.Caller
	var selection governance.Selection
	if runID != "" {
		r, e := service.Read(runID)
		if e != nil {
			return nil, e
		}
		selection = r.Run.Selection
		if attemptID != "" || epoch != "" {
			caller, e = governance.AssignedAgent(runID, attemptID, epoch)
			if e != nil {
				return nil, e
			}
		}
	} else if attemptID != "" || epoch != "" {
		return nil, fmt.Errorf("attempt binding requires a run")
	}
	s := mcp.NewServer(&mcp.Implementation{Name: "sdptool-governance", Version: "PGI2"},
		&mcp.ServerOptions{SupportedProtocolVersions: []string{ProtocolVersion}})
	add := func(name, description string, schema map[string]any, readOnly bool, f func([]byte) (any, error)) {
		addTool(s, name, description, schema, readOnly, responsePolicy{governance.Schema, "use bounded observation pages"}, f)
	}
	if coordinator != "" {
		add("coordination_read", "Read a bounded page of registered work, questions and reports in the launch-selected checkout. No host liveness or acceptance is inferred. A stale cursor requires a fresh first page.", governance.WireDefinition("CoordinationRequest"), true, func(b []byte) (any, error) {
			var q governance.CoordinationRequest
			if e := governance.Decode(b, &q); e != nil {
				return nil, e
			}
			return service.Coordination(q)
		})
		add("report_acknowledge", "Record processing of an exact current report under the launcher's coordinator identity. Does not accept, complete, publish or continue work. Preserve operationId on retry.", governance.WireDefinition("ReportAcknowledgementRequest"), false, func(b []byte) (any, error) {
			var q governance.ReportAcknowledgementRequest
			if e := governance.Decode(b, &q); e != nil {
				return nil, e
			}
			if q.Coordinator != coordinator {
				return nil, &governance.Error{Code: "unauthorized", Message: "coordinator differs from launcher identity"}
			}
			return service.AcknowledgeReport(governance.LocalController(), q)
		})
		return s, nil
	}
	denied := func() error {
		return &governance.Error{Code: "unauthorized", Message: "request is outside launch-bound assignment"}
	}
	add("context_read", "Read project context; never creates work.", governance.WireDefinition("Selection"), true, func(b []byte) (any, error) {
		var q governance.Selection
		if e := governance.Decode(b, &q); e != nil {
			return nil, e
		}
		if runID != "" && q != selection {
			return nil, denied()
		}
		if runID != "" {
			return service.RunContext(runID)
		}
		return service.Context(q)
	})
	add("route_evaluate", "Evaluate a proposed route without activating work.", governance.WireDefinition("RouteRequest"), true, func(b []byte) (any, error) {
		var q governance.RouteRequest
		if e := governance.Decode(b, &q); e != nil {
			return nil, e
		}
		if runID != "" && q.Selection != selection {
			return nil, denied()
		}
		return service.Route(q)
	})
	add("run_read", "Read only the launch-bound run.", map[string]any{"type": "object", "properties": map[string]any{}, "additionalProperties": false}, true, func(b []byte) (any, error) {
		var q struct{}
		if e := governance.Decode(b, &q); e != nil {
			return nil, e
		}
		if runID == "" {
			return nil, denied()
		}
		return service.Read(runID)
	})
	if attemptID != "" {
		add("attention_read", "Read questions, attributed replies and current applicability for the assigned run. Supply questionId from attention_request to bound large histories. Reading does not consume an answer.", map[string]any{"type": "object", "properties": map[string]any{"questionId": map[string]any{"type": "string", "format": "uuid"}}, "additionalProperties": false}, true, func(b []byte) (any, error) {
			var q struct {
				QuestionID string `json:"questionId"`
			}
			if e := governance.Decode(b, &q); e != nil {
				return nil, e
			}
			view, e := service.AttentionInbox(runID)
			if e != nil || q.QuestionID == "" {
				return view, e
			}
			for _, item := range view.Items {
				if item.Question.ID == q.QuestionID {
					view.Items = []governance.AttentionView{item}
					return view, nil
				}
			}
			return nil, &governance.Error{Code: "missing_coverage", Message: "question absent from assigned run"}
		})
		add("attention_request", "Ask a durable question for the assigned run; a blocking question prevents report advancement. Stop dependent work while waiting. Read replies and applicability through attention_read; asking grants no owner authority.", governance.WireDefinition("AttentionRequest"), false, func(b []byte) (any, error) {
			var q governance.AttentionRequest
			if e := governance.Decode(b, &q); e != nil {
				return nil, e
			}
			return service.RequestAttention(caller, q)
		})
		add("events_read", "Read a bounded page of observations for the launch-bound attempt; cursor pins the run revision.", map[string]any{
			"type": "object", "additionalProperties": false, "properties": map[string]any{"cursor": map[string]any{"type": "string"}, "limit": map[string]any{"type": "integer", "minimum": 1, "maximum": 256}}, "required": []string{"cursor", "limit"}}, true, func(b []byte) (any, error) {
			var q struct {
				Cursor string `json:"cursor"`
				Limit  int    `json:"limit"`
			}
			if e := governance.Decode(b, &q); e != nil {
				return nil, e
			}
			return service.Events(runID, attemptID, q.Cursor, q.Limit)
		})
		schema := governance.WireDefinition("TransitionRequest")
		schema["properties"].(map[string]any)["action"] = map[string]any{"enum": []string{"report", "fail", "scope-change"}}
		add("run_transition", "Report, fail or request replanning for the assigned run; cannot start, resume, accept or complete work.", schema, false, func(b []byte) (any, error) {
			var q governance.TransitionRequest
			if e := governance.Decode(b, &q); e != nil {
				return nil, e
			}
			return service.Transition(caller, q)
		})
	}
	return s, nil
}
