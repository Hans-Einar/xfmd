package governance

import (
	"bytes"
	"encoding/json"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"runtime"
	"testing"
)

func TestSessionHostSelectionAndCompiledStatus(t *testing.T) {
	s, q := workFixture(t, "", "")
	binary := filepath.Join(t.TempDir(), "sdp-controller")
	if b, e := exec.Command(filepath.Join(runtime.GOROOT(), "bin", "go"), "build", "-o", binary, "../cmd/sdp-controller").CombinedOutput(); e != nil {
		t.Fatal(e, string(b))
	}
	call := func(action string, extra ...string) ([]byte, error) {
		args := []string{action, "--project", s.root, "--state", s.state, "--instance", q.InstanceID}
		return exec.Command(binary, append(args, extra...)...).CombinedOutput()
	}
	if _, e := s.SessionHostSelection(q.InstanceID); e == nil {
		t.Fatal("uncommitted assignment selected")
	}
	b, e := call("status")
	if e != nil || !json.Valid(b) {
		t.Fatal(e, string(b))
	}
	head := mustFile(t, filepath.Join(s.state, "HEAD"))
	if b, e = call("run", "--codex", "/missing/native-host", "--mcp-binary", "/missing/mcp"); e == nil || !bytes.Contains(b, []byte("no current committed assignment")) {
		t.Fatal(e, string(b))
	}
	if !bytes.Equal(head, mustFile(t, filepath.Join(s.state, "HEAD"))) {
		t.Fatal("inspection/refusal wrote state")
	}
	p, e := s.StartSession(LocalController(), q)
	if e != nil {
		t.Fatal(e)
	}
	if _, e = s.SessionHostSelection(q.InstanceID); e == nil {
		t.Fatal("prepared start selected")
	}
	done, e := s.ResumeSession(LocalController(), workResume(q, p))
	if e != nil {
		t.Fatal(e)
	}
	selected, e := s.SessionHostSelection(q.InstanceID)
	if e != nil || selected.RunID != q.OperationID || selected.Revision != done.Revision || selected.Outcome != q.Outcome || !reflect.DeepEqual(selected.Skills, q.Skills) {
		t.Fatal(selected, e)
	}
	b, e = call("status")
	if e != nil {
		t.Fatal(e, string(b))
	}
	decoder := json.NewDecoder(bytes.NewReader(b))
	var v SessionView
	var r Result
	if decoder.Decode(&v) != nil || decoder.Decode(&r) != nil || v.InstanceID != q.InstanceID || r.Run.ID != q.OperationID {
		t.Fatal(string(b))
	}
	var extra any
	if decoder.Decode(&extra) != io.EOF {
		t.Fatal("unexpected status object")
	}
	if b, e = call("status", "--run", q.OperationID); e == nil || !bytes.Contains(b, []byte("exactly one")) {
		t.Fatal(e, string(b))
	}
	evidenceFile(t, s, "SDP/authority.md", "Changed authority; do not dispatch.\n")
	head = mustFile(t, filepath.Join(s.state, "HEAD"))
	if b, e = call("run", "--codex", "/missing/native-host", "--mcp-binary", "/missing/mcp"); e == nil || !bytes.Contains(b, []byte("stale_revision")) {
		t.Fatal(e, string(b))
	}
	if !bytes.Equal(head, mustFile(t, filepath.Join(s.state, "HEAD"))) {
		t.Fatal("stale launch changed state")
	}
}

// Opt-in setup only. Native submission is a separate explicit controller command;
// ordinary tests never submit model work or read account configuration.
func TestSessionHostNativeFixture(t *testing.T) {
	root, state := os.Getenv("PG_SESSION_HOST_LAB_ROOT"), os.Getenv("PG_SESSION_HOST_LAB_STATE")
	if root == "" {
		t.Skip("explicit native lab setup only")
	}
	if state == "" {
		t.Fatal("private state required")
	}
	source, e := filepath.Abs("../../Skills")
	if e != nil {
		t.Fatal(e)
	}
	s, q := workConfigured(t, root, state, func(t *testing.T, s *Service, b *SessionBinding) {
		evidenceFile(t, s, "AGENTS.md", "# Authorized native Session fixture\n\nThis isolated pg_lab task is authorized by its owner for PG development testing.\nUse the supplied existing Session/plan/card and pinned Master/Worker skills.\nChange only target.txt as the committed assignment requests; inspect its exact bytes\nto verify the result. This is a no-design wording change. Do not create another\nSession or plan, publish records, edit skills or configuration, spawn/delegate, use\nthe network, install packages, commit or push. The controller owns canonical\nSession/KanBan effects. Report through assignment-bound MCP and return.\nThe minimal manifest and fixture authority govern this trial; no full Toolkit\ninstallation or release claim is made. Preserve every other file.\n")
		if os.Getenv("PG_SESSION_HOST_REQUEST") == "leader" {
			evidenceFile(t, s, "AGENTS.md", "# Authorized Project Leader host-request trial\n\nThis isolated pg_lab task is authorized by the owner for PG development testing.\nThe explicitly launched Project Leader must load sdp-project-leader, read the\nselected Session and committed assignment through its granted MCP server, and\nmay queue exactly that assignment with session_host_request. Use the skill from\nsession_definition and current revisions from session_host_read. This specific\nfixture extends the earlier coordinator-only leader trial: the leader still may\nnot launch native children, directly edit files, grant owner acceptance, approve\ndesign, install packages, use the network, commit or push. The trusted controller\nexecutes queued requests. Other goals need separate KB/Session/plan coverage.\nA launched Master/Worker may change only target.txt as its committed assignment\nrequests, verify the exact bytes, report via assignment-bound MCP and return.\nCanonical records, skills and configuration are controller-owned. The minimal\nmanifest and fixture authority govern this trial; no full Toolkit or release claim.\n")
		}
		if e := filepath.WalkDir(source, func(path string, entry os.DirEntry, err error) error {
			if err != nil {
				return err
			}
			rel, err := filepath.Rel(source, path)
			if err != nil {
				return err
			}
			dest := filepath.Join(s.root, "Skills", rel)
			if entry.IsDir() {
				return os.MkdirAll(dest, 0700)
			}
			data, err := os.ReadFile(path)
			if err != nil {
				return err
			}
			return os.WriteFile(dest, data, 0600)
		}); e != nil {
			t.Fatal(e)
		}
		if e := os.MkdirAll(filepath.Join(s.root, ".agents/skills"), 0700); e != nil {
			t.Fatal(e)
		}
		for _, name := range []string{"sdp", "sdp-master", "sdp-worker", "sdp-project-leader"} {
			if e := os.Symlink(filepath.Join("../../Skills", name), filepath.Join(s.root, ".agents/skills", name)); e != nil {
				t.Fatal(e)
			}
		}
	}, func(a *SessionAssessRequest) {
		if os.Getenv("PG_SESSION_HOST_REQUEST") == "" {
			return
		}
		for n, skill := range a.Skills {
			data := mustFile(t, filepath.Join(source, skill.Name, "SKILL.md"))
			if err := os.WriteFile(skill.Path, data, 0600); err != nil {
				t.Fatal(err)
			}
			a.Skills[n].Digest = hash(data)
		}
	})
	// The generic service fixture creates synthetic launch skills. Replace only those
	// uncommitted inputs with canonical copies before preparing this native assignment.
	for n, sk := range q.Skills {
		data := mustFile(t, filepath.Join(source, sk.Name, "SKILL.md"))
		if e = os.WriteFile(sk.Path, data, 0600); e != nil {
			t.Fatal(e)
		}
		q.Skills[n].Digest = hash(data)
	}
	q.Outcome = "Replace the entire contents of target.txt with exactly PG Session native execution verified. followed by one newline. Read the resulting file to verify exact bytes; preserve all other files. This is a wording-only correction with no design change. Report the outcome through assignment-bound MCP and return."
	if os.Getenv("PG_SESSION_HOST_LAB_ATTENTION") == "1" {
		q.Outcome = "Before editing target.txt, request a blocking owner answer through assignment-bound attention_request: ask which sentence to write, with option short for PG Session native reply verified. and option long for PG Session native owner reply verified. If no current reply is available, return waiting without editing or reporting completion. On a continuation, reuse the existing answered question; do not ask it again. After the recorded owner answer, replace all of target.txt with the chosen sentence followed by exactly one newline, inspect it to verify, preserve every other file, then report through assignment-bound MCP and return. This is a wording-only no-design task."
	}
	q.Reason = "Start the owner-authorized native Session entry-point trial"
	_, r := startWork(t, s, q)
	selected, e := s.SessionHostSelection(q.InstanceID)
	if e != nil {
		t.Fatal(e)
	}
	if selected.Outcome != q.Outcome || r.Run.State != "ready" {
		t.Fatal(selected)
	}
	if os.Getenv("PG_SESSION_HOST_REQUEST") == "1" {
		skill, err := s.SessionLeaderSkill(q.InstanceID, "Skills/sdp-project-leader/SKILL.md")
		if err != nil {
			t.Fatal(err)
		}
		hostRequest := SessionHostRequest{Schema: SessionHostSchema, ProjectRef: s.project, CheckoutID: r.CheckoutID, OperationID: newTestID(), InstanceID: q.InstanceID, ExpectedRevision: selected.Revision, RunID: r.Run.ID, ExpectedRunRevision: r.Run.Revision, Action: "launch", Reason: "Execute the authorized native Session host-request trial", LeaderSkill: skill}
		command, err := s.RequestSessionHost(LocalController(), hostRequest)
		if err != nil {
			t.Fatal(err)
		}
		data, _ := json.MarshalIndent(command, "", "  ")
		if err = os.WriteFile(filepath.Join(root, "evidence/native-host-request.json"), data, 0600); err != nil {
			t.Fatal(err)
		}
	}
	out, _ := json.MarshalIndent(selected, "", "  ")
	if e = os.WriteFile(filepath.Join(root, "evidence/native-launch.json"), out, 0600); e != nil {
		t.Fatal(e)
	}
}
