// Package governancecontroller coordinates trusted owner input and observed host
// effects. It never treats a host response as SDP evidence acceptance.
package governancecontroller

import (
	"context"
	"encoding/json"
	"fmt"
	"slices"
	"strings"
	"time"

	"github.com/Hans-Einar/SDP/SDPTool/governance"
	"github.com/Hans-Einar/SDP/SDPTool/governancehost"
)

type Host interface {
	AccountMode(context.Context) (string, error)
	MCPTools(context.Context, string, string) ([]string, string, error)
	StartWorkThread(context.Context, string, string, string, string, map[string]any) (governancehost.Thread, error)
	StartTurn(context.Context, string, string, string) (governancehost.Turn, error)
	SteerTurn(context.Context, string, string, string, string) error
	InterruptTurn(context.Context, string, string) error
}

type Controller struct {
	SessionHostInputID                                                            string // Set only by the trusted Session command executor.
	SkillPaths                                                                    []string
	Service                                                                       *governance.Service
	Host                                                                          Host
	Root, StateDir, MCPBinary, Epoch, Sandbox, Approvals, Reporting, HostIdentity string
}

// Retry only bookkeeping rejected before mutation. Never retry a host effect.
func retryRecord(f func() (governance.Result, error)) (r governance.Result, e error) {
	for i := 0; i < 100; i++ {
		r, e = f()
		if e == nil {
			return r, nil
		}
		ge, ok := e.(*governance.Error)
		if !ok || (ge.Code != "busy" && ge.Code != "stale_revision") {
			return r, e
		}
		if i < 99 {
			time.Sleep(20 * time.Millisecond)
		}
	}
	return r, e
}
func (c *Controller) input(runID, action string, v governance.OwnerInput) (governance.Result, error) {
	return retryRecord(func() (governance.Result, error) {
		r, e := c.Service.Read(runID)
		if e != nil {
			return r, e
		}
		return c.Service.RecordInput(governance.LocalController(), governance.InputRequest{Schema: governance.Schema, ProjectRef: r.ProjectRef, CheckoutID: r.CheckoutID, RunID: runID, OperationID: governancehost.UUID(), ExpectedRevision: r.Run.Revision, InputRevision: r.Run.InputRevision, Action: action, Input: v})
	})
}
func (c *Controller) transition(runID, action, reason string) (governance.Result, error) {
	r, e := c.Service.Read(runID)
	if e != nil {
		return r, e
	}
	return c.Service.Transition(governance.LocalController(), governance.TransitionRequest{Schema: governance.Schema, ProjectRef: r.ProjectRef, CheckoutID: r.CheckoutID, RunID: runID, OperationID: governancehost.UUID(), ExpectedRevision: r.Run.Revision, InputRevision: r.Run.InputRevision, Action: action, Reason: reason})
}
func (c *Controller) record(runID, attemptID, threadID, action string, o governance.Observation) (governance.Result, error) {
	observed, ok := c.Host.(interface{ Version() string })
	if !ok {
		return governance.Result{}, fmt.Errorf("incompatible_profile: observed host version required")
	}
	version := observed.Version()
	if version == "" {
		return governance.Result{}, fmt.Errorf("incompatible_profile: observed host version required")
	}
	return retryRecord(func() (governance.Result, error) {
		r, e := c.Service.Read(runID)
		if e != nil {
			return r, e
		}
		return c.Service.RecordHost(governance.LocalController(), governance.HostRequest{HostIdentity: c.HostIdentity, Schema: governance.Schema, ProjectRef: r.ProjectRef, CheckoutID: r.CheckoutID, RunID: runID, OperationID: governancehost.UUID(), ExpectedRevision: r.Run.Revision, InputRevision: r.Run.InputRevision, Action: action, AttemptID: attemptID, HostVersion: version, ThreadID: threadID, Observation: o})
	})
}
func now() string { return time.Now().UTC().Format(time.RFC3339Nano) }

// Launch consumes a new intent once while holding the controller lease. Failures
// after claim remain uncertain, even if an RPC may have succeeded. No retry sends.
func (c *Controller) Launch(ctx context.Context, runID, text string) (governance.Result, error) {
	return c.launch(ctx, runID, text, false)
}

func (c *Controller) launch(ctx context.Context, runID, text string, continuing bool) (result governance.Result, err error) {
	unlock, e := c.Service.RunControllerLease(governance.LocalController(), runID)
	if e != nil {
		return result, e
	}
	defer unlock()
	if c.MCPBinary == "" || (c.Sandbox != "read-only" && c.Sandbox != "workspace-write") {
		return result, fmt.Errorf("explicit MCP executable and sandbox required")
	}
	reporting := c.Reporting
	if reporting == "" {
		reporting = "manual"
	}
	if reporting != "manual" && reporting != "automatic" {
		return result, fmt.Errorf("unsupported reporting mode")
	}
	mode, e := c.Host.AccountMode(ctx)
	if e != nil {
		return result, e
	}
	if mode != "chatgpt" {
		return result, fmt.Errorf("managed ChatGPT mode required; no billing fallback")
	}
	r, e := c.Service.Read(runID)
	if e != nil {
		return r, e
	}
	var continuation continuationContext
	if continuing {
		continuation, e = c.continuationContext(runID)
		if e != nil {
			return r, e
		}
		text = continuation.Original.Text
		copy := *c
		copy.SkillPaths, e = continuationSkillPaths(c.Root, continuation.Original.Skills)
		if e != nil {
			return r, e
		}
		c = &copy
	}
	coverage, e := c.Service.RunContext(runID)
	if e != nil {
		return r, e
	}
	inventory, selected, e := c.selectSkills(ctx)
	if e != nil {
		return r, e
	}
	instructions := "You are the fresh Master for one explicitly authorized SDP Maintenance assignment. Read the selected Session, authority, plan, card, AGENTS and relevant SDP skills before acting. Preserve writable/excluded boundaries and unrelated work. Native delegation is not granted by this launch; do not spawn children. Report candidate, tests, remaining gaps and observed outcome. Agent claims do not grant owner approval or independent review. Do not publish canonical management/Session records or mark the work complete; evidence publication is a later controller capability. Use assignment-bound MCP reads, attention questions and report/fail/scope-change only. For input you need, use attention_request with blocking=true, stop dependent work, and read any reply and its current applicability via attention_read. If no reply is available, return a waiting summary; do not poll indefinitely or invent an answer. A reply records input, not authority to change scope."
	approvedDesign, e := c.Service.RunDesign(runID)
	if e != nil {
		return r, e
	}
	sessionWork, e := c.Service.RunSession(runID)
	if e != nil {
		return r, e
	}
	if sessionWork != nil {
		instructions = strings.ReplaceAll(instructions, "SDP Maintenance assignment", "SDP Session assignment")
		instructions += " Use the exact Session step and every selected card contribution in sessionWork. The explicit no-design assessment does not authorize design changes: report scope-change if implementation requires a design change."
	}
	if approvedDesign != nil {
		instructions = strings.ReplaceAll(instructions, "SDP Maintenance assignment", "SDP implementation assignment")
		instructions = "You are the Master for the exact approved SDP implementation package. Use the included design basis, task constraints, Session and ImplementationPlan. Do not change NOW/TARGET, broaden scope or treat host completion as approval. " + instructions
	}
	if continuing {
		if !slices.Equal(selected, continuation.Original.Skills) {
			return r, fmt.Errorf("conflict: continuation skill selection changed")
		}
		instructions += " This is a fresh continuation attempt after recorded attention replies. Reuse the original assignment and existing working files. Read attentionContext: it distinguishes historical replies from the exact replies selected by attentionReferences. Do not ask the same resolved question again. Continue only within the original mandate; report or raise a new question when required."
	}
	payload, e := json.Marshal(map[string]any{"sessionWork": sessionWork, "attentionContext": continuation.History, "attentionReferences": continuation.References, "approvedDesign": approvedDesign, "ownerInput": text, "assignment": r.Run.Assignment, "context": coverage, "runId": runID, "instructions": instructions, "sandbox": c.Sandbox, "approvalMode": c.Approvals, "reportingMode": reporting})
	if e != nil {
		return r, e
	}
	wireText := string(payload)
	if len(selected) > 0 {
		markers := ""
		for _, skill := range selected {
			markers += "$" + skill.Name + " "
		}
		wireText = markers + "\n" + wireText
	}
	inputID := c.SessionHostInputID
	if inputID == "" {
		inputID = governancehost.UUID()
	}
	v := governance.OwnerInput{AttentionReplies: continuation.References, Skills: selected, ID: inputID, Kind: "launch", Text: text, Payload: wireText, AttemptID: governancehost.UUID(), Epoch: c.Epoch, ReceivedAt: now()}
	if _, e = c.input(runID, "prepare", v); e != nil {
		return r, e
	}
	v.State = "prepared"
	if _, e = c.input(runID, "claim", v); e != nil {
		return r, e
	}
	v.State = "sending"
	defer func() {
		if err != nil {
			_, _ = c.input(runID, "uncertain", v)
		}
	}()
	config := map[string]any{"sdp_governance": map[string]any{"command": c.MCPBinary, "args": []string{"--project", c.Root, "--state", c.StateDir, "--run", runID, "--attempt", v.AttemptID, "--epoch", c.Epoch}}}
	if reporting == "automatic" {
		config["sdp_governance"].(map[string]any)["tools"] = map[string]any{"run_transition": map[string]any{"approval_mode": "approve"}, "attention_request": map[string]any{"approval_mode": "approve"}}
	}
	thread, e := c.Host.StartWorkThread(ctx, c.Root, c.Sandbox, instructions, c.Approvals, config)
	if e != nil {
		return r, e
	}
	v.ThreadID = thread.ID
	r, e = c.record(runID, v.AttemptID, thread.ID, "bind", governance.Observation{Kind: "bound", Status: "idle", Epoch: c.Epoch, ReceivedAt: now()})
	if e != nil {
		return r, e
	}
	// Record exactly what the controller and host can substantiate. A discovery
	// result is not skill activation, and an assigned role is not a native role.
	provenance := governance.ContextProvenance{AssignedRole: "Master", RoleBasis: "controller-launch", InputRevision: r.Run.InputRevision, Sources: coverage.Sources, Host: thread.Context, Skills: governance.SkillInventory{Status: "unavailable", UseEvidence: "not-observed", Project: []governance.SkillAvailability{}}}
	if provenance.Host.Status == "" {
		provenance.Host = governance.HostContext{Status: "unavailable", InstructionStatus: "unavailable", InstructionSources: []string{}}
	}
	provenance.Skills = inventory
	encoded, err := json.Marshal(provenance)
	if err != nil {
		return r, err
	}
	r, e = c.record(runID, v.AttemptID, thread.ID, "observe", governance.Observation{Kind: "context.observed", ItemID: "launch", Text: string(encoded), Epoch: c.Epoch, ReceivedAt: now()})
	if e != nil {
		return r, e
	}
	names, _, e := c.Host.MCPTools(ctx, "sdp_governance", thread.ID)
	if e != nil {
		return r, e
	}
	if !slices.Equal(names, []string{"attention_read", "attention_request", "context_read", "events_read", "route_evaluate", "run_read", "run_transition"}) {
		return r, fmt.Errorf("assignment-bound MCP tools unavailable")
	}
	r, e = c.transition(runID, "start", "owner selected fresh bounded Master attempt")
	if e != nil {
		return r, e
	}
	if e = governance.CheckSkillSnapshots(c.Root, v.Skills); e != nil {
		return r, e
	}
	if e = c.Service.CheckActivityDispatch(governance.LocalController(), runID, v.ID); e != nil {
		return r, e
	}
	var turn governancehost.Turn
	if len(v.Skills) > 0 {
		turn, e = c.Host.(skillHost).StartSkillTurn(ctx, thread.ID, v.ID, v.Payload, v.Skills)
	} else {
		turn, e = c.Host.StartTurn(ctx, thread.ID, v.ID, v.Payload)
	}
	if e != nil {
		return r, e
	}
	v.TurnID = turn.ID
	r, e = c.record(runID, v.AttemptID, thread.ID, "observe", governance.Observation{Kind: "turn.started", TurnID: turn.ID, Status: "running", Epoch: c.Epoch, ReceivedAt: now()})
	if e != nil {
		return r, e
	}
	return c.input(runID, "ack", v)
}

// Control records exact owner input before steering or interrupting. A scope
// change stops the routine before attempting a host interrupt; it never expands
// the existing assignment. Uncertain requests remain visible and are not resent.
func (c *Controller) Control(ctx context.Context, runID, kind, text string) (result governance.Result, err error) {
	unlock, e := c.Service.RunControllerLease(governance.LocalController(), runID)
	if e != nil {
		return result, e
	}
	defer unlock()
	if kind != "steer" && kind != "interrupt" && kind != "scope-change" {
		return result, fmt.Errorf("unsupported owner command")
	}
	r, e := c.Service.Read(runID)
	if e != nil {
		return r, e
	}
	if len(r.Run.Attempts) == 0 {
		return r, fmt.Errorf("no mapped attempt")
	}
	a := r.Run.Attempts[len(r.Run.Attempts)-1]
	if a.Epoch != c.Epoch {
		return r, fmt.Errorf("reconciliation_required: controller epoch changed")
	}
	inputID := c.SessionHostInputID
	if inputID == "" {
		inputID = governancehost.UUID()
	}
	v := governance.OwnerInput{ID: inputID, Kind: kind, Text: text, Payload: text, AttemptID: a.ID, Epoch: c.Epoch, ThreadID: a.ThreadID, TurnID: a.TurnID, ReceivedAt: now()}
	if _, e = c.input(runID, "prepare", v); e != nil {
		return r, e
	}
	v.State = "prepared"
	if _, e = c.input(runID, "claim", v); e != nil {
		return r, e
	}
	v.State = "sending"
	defer func() {
		if err != nil {
			_, _ = c.input(runID, "uncertain", v)
		}
	}()
	if kind == "steer" {
		if e = c.Service.CheckActivityDispatch(governance.LocalController(), runID, v.ID); e != nil {
			return r, e
		}
		e = c.Host.SteerTurn(ctx, a.ThreadID, a.TurnID, v.ID, text)
	} else {
		action := "interrupt"
		if kind == "scope-change" {
			action = kind
		}
		if _, e = c.transition(runID, action, text); e != nil {
			return r, e
		}
		e = c.Host.InterruptTurn(ctx, a.ThreadID, a.TurnID)
	}
	if e != nil {
		return r, e
	}
	return c.input(runID, "ack", v)
}
func (c *Controller) Observe(runID string, event governancehost.Event) (governance.Result, error) {
	r, e := c.Service.Read(runID)
	if e != nil {
		return r, e
	}
	if len(r.Run.Attempts) == 0 {
		return r, fmt.Errorf("no mapped attempt")
	}
	a := r.Run.Attempts[len(r.Run.Attempts)-1]
	if event.ThreadID != a.ThreadID || event.Observation.Epoch != c.Epoch || a.Epoch != c.Epoch {
		return r, fmt.Errorf("observation outside current attempt")
	}
	return c.record(runID, a.ID, a.ThreadID, "observe", event.Observation)
}
func (c *Controller) Disconnect(runID string) (governance.Result, error) {
	r, e := c.Service.Read(runID)
	if e != nil {
		return r, e
	}
	if len(r.Run.Attempts) == 0 {
		return r, nil
	}
	a := r.Run.Attempts[len(r.Run.Attempts)-1]
	return c.record(runID, a.ID, a.ThreadID, "disconnect", governance.Observation{Kind: "disconnected", Status: "unknown", Epoch: c.Epoch, ReceivedAt: now()})
}
