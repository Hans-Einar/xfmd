#!/usr/bin/env python3
import argparse
import json
import math
from pathlib import Path


WEIGHTS = {
    # Crossing/overlap terms are still dominant readability drivers.
    "edge_crossings": 5.0,
    "edge_crossings_per_edge": 4.0,
    "edge_node_crossings": 6.0,
    "node_overlap_count": 12.0,
    "edge_bends": 2.0,
    "port_congestion": 2.0,
    "edge_overlap_length": 1.0,
    "crossing_angle_penalty": 3.0,
    "angular_resolution_penalty": 2.5,
    "node_spacing_violation_count": 2.0,
    "edge_node_near_miss_count": 1.5,
    "edge_node_crossing_length_per_edge": 0.6,
    "subgraph_boundary_intrusion_ratio": 55.0,
    "subgraph_boundary_intrusion_length_per_edge": 0.9,
    "port_target_side_mismatch_ratio": 45.0,
    "port_direction_misalignment_ratio": 35.0,
    "endpoint_off_boundary_ratio": 70.0,
    "parallel_edge_overlap_ratio_mean": 60.0,
    "parallel_edge_separation_bad_ratio": 48.0,
    "flow_backtrack_ratio": 90.0,
    "flow_backtracking_edge_ratio": 50.0,
    # Normalize geometric terms so large diagrams are comparable with small ones.
    "edge_length_per_node": 0.75,
    "edge_detour_penalty": 80.0,
    # Explicit whitespace and composition quality.
    "space_efficiency_penalty": 320.0,
    # Prioritize whitespace waste primarily when diagrams are large.
    "wasted_space_large_ratio": 340.0,
    "space_efficiency_large_penalty": 360.0,
    "component_gap_large_ratio": 220.0,
    "margin_imbalance_ratio": 160.0,
    # Ownership-aware edge-label quality (diagram-specific optimal gap).
    "edge_label_owned_path_too_close_ratio": 180.0,
    "edge_label_owned_path_optimal_gap_penalty": 140.0,
    "edge_label_owned_path_gap_bad_ratio": 160.0,
    "edge_label_owned_alignment_bad_ratio": 120.0,
    "edge_label_owned_path_gap_mean": 4.0,
    "edge_label_owned_anchor_offset_bad_ratio": 140.0,
    "edge_label_owned_anchor_offset_px_mean": 2.2,
}


def load_layout(path: Path):
    data = json.loads(path.read_text())
    nodes = {}
    for node in data.get("nodes", []):
        if node.get("hidden"):
            continue
        if node.get("anchor_subgraph") is not None:
            continue
        clean = dict(node)
        for key in ("x", "y", "width", "height"):
            try:
                clean[key] = float(clean.get(key, 0.0))
            except (TypeError, ValueError):
                clean[key] = 0.0
        nodes[node["id"]] = clean
    edges = data.get("edges", [])
    return data, nodes, edges


def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def safe_ratio(num, den, default=0.0):
    if abs(den) < 1e-9:
        return default
    return num / den


def clamp(value, lo, hi):
    return max(lo, min(hi, value))


def smoothstep_ramp(value, start, end):
    if end <= start:
        return 1.0 if value >= end else 0.0
    t = clamp((value - start) / (end - start), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def segments_from_points(points):
    if len(points) < 2:
        return []
    return list(zip(points, points[1:]))


def orient(a, b, c):
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def on_segment(a, b, c, eps):
    return (
        min(a[0], b[0]) - eps <= c[0] <= max(a[0], b[0]) + eps
        and min(a[1], b[1]) - eps <= c[1] <= max(a[1], b[1]) + eps
    )


def segments_intersect(a, b, c, d, eps=1e-6):
    o1 = orient(a, b, c)
    o2 = orient(a, b, d)
    o3 = orient(c, d, a)
    o4 = orient(c, d, b)

    if abs(o1) < eps and abs(o2) < eps and abs(o3) < eps and abs(o4) < eps:
        return False
    if o1 * o2 < 0 and o3 * o4 < 0:
        return True
    if abs(o1) < eps and on_segment(a, b, c, eps):
        return True
    if abs(o2) < eps and on_segment(a, b, d, eps):
        return True
    if abs(o3) < eps and on_segment(c, d, a, eps):
        return True
    if abs(o4) < eps and on_segment(c, d, b, eps):
        return True
    return False


def collinear_overlap_length(a, b, c, d, eps=1e-6):
    if abs(orient(a, b, c)) > eps or abs(orient(a, b, d)) > eps:
        return 0.0
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    seg_len_sq = dx * dx + dy * dy
    if seg_len_sq < eps:
        return 0.0

    def proj(p):
        return ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / seg_len_sq

    t1 = proj(c)
    t2 = proj(d)
    tmin = min(t1, t2)
    tmax = max(t1, t2)
    overlap = max(0.0, min(1.0, tmax) - max(0.0, tmin))
    return overlap * math.sqrt(seg_len_sq)


def bend_count(points, eps=1e-6):
    if len(points) < 3:
        return 0
    bends = 0
    for i in range(1, len(points) - 1):
        a = points[i - 1]
        b = points[i]
        c = points[i + 1]
        v1 = (b[0] - a[0], b[1] - a[1])
        v2 = (c[0] - b[0], c[1] - b[1])
        if abs(v1[0]) < eps and abs(v1[1]) < eps:
            continue
        if abs(v2[0]) < eps and abs(v2[1]) < eps:
            continue
        cross = v1[0] * v2[1] - v1[1] * v2[0]
        if abs(cross) > eps:
            bends += 1
    return bends


def infer_side(node, point, tol=1.0):
    x = node["x"]
    y = node["y"]
    w = node["width"]
    h = node["height"]
    px, py = point
    sides = {
        "left": abs(px - x),
        "right": abs(px - (x + w)),
        "top": abs(py - y),
        "bottom": abs(py - (y + h)),
    }
    side, delta = min(sides.items(), key=lambda item: item[1])
    if delta <= tol:
        return side
    return "unknown"


def opposite_side(side):
    return {
        "left": "right",
        "right": "left",
        "top": "bottom",
        "bottom": "top",
    }.get(side)


def dominant_axis_side(dx, dy, eps=1e-9):
    if abs(dx) < eps and abs(dy) < eps:
        return None
    if abs(dx) >= abs(dy):
        return "right" if dx >= 0.0 else "left"
    return "bottom" if dy >= 0.0 else "top"


def node_center(node):
    return (
        node["x"] + node["width"] * 0.5,
        node["y"] + node["height"] * 0.5,
    )


def expected_side_towards(src_node, dst_node):
    sx, sy = node_center(src_node)
    dx, dy = node_center(dst_node)
    return dominant_axis_side(dx - sx, dy - sy)


def point_rect_boundary_distance(point, node):
    x1 = node["x"]
    y1 = node["y"]
    x2 = x1 + node["width"]
    y2 = y1 + node["height"]
    px, py = point
    if x1 <= px <= x2 and y1 <= py <= y2:
        return min(px - x1, x2 - px, py - y1, y2 - py)
    cx = clamp(px, x1, x2)
    cy = clamp(py, y1, y2)
    return math.hypot(px - cx, py - cy)


# Shapes whose drawn outline is inscribed within the bounding rect, so an edge
# endpoint that correctly touches the visible boundary lies *inside* the rect.
# For these, rect-edge distance wrongly reports the endpoint as off-boundary;
# we measure distance to the actual outline instead.
_INSCRIBED_SHAPES = {
    "Diamond",
    "Circle",
    "DoubleCircle",
    "Hexagon",
    "Cylinder",
    "Parallelogram",
    "ParallelogramAlt",
    "Trapezoid",
    "TrapezoidAlt",
    "Asymmetric",
    "Stadium",
}


def _shape_polygon(node):
    """Approximate outline polygon for the node's shape, matching the renderer's
    `shape_polygon_points`. Returns None for shapes handled analytically
    (circles) or unknown shapes (caller falls back to rect)."""
    x = node["x"]
    y = node["y"]
    w = node["width"]
    h = node["height"]
    shape = node.get("shape", "Rectangle")
    if shape == "Diamond":
        cx, cy = x + w / 2.0, y + h / 2.0
        return [(cx, y), (x + w, cy), (cx, y + h), (x, cy)]
    if shape == "Hexagon":
        x1, x2 = x + w * 0.25, x + w * 0.75
        ym = y + h / 2.0
        return [(x1, y), (x2, y), (x + w, ym), (x2, y + h), (x1, y + h), (x, ym)]
    if shape in ("Parallelogram", "ParallelogramAlt"):
        off = w * 0.18
        if shape == "Parallelogram":
            return [(x + off, y), (x + w, y), (x + w - off, y + h), (x, y + h)]
        return [(x, y), (x + w - off, y), (x + w, y + h), (x + off, y + h)]
    if shape in ("Trapezoid", "TrapezoidAlt"):
        off = w * 0.18
        if shape == "Trapezoid":
            return [(x + off, y), (x + w - off, y), (x + w, y + h), (x, y + h)]
        return [(x, y), (x + w, y), (x + w - off, y + h), (x + off, y + h)]
    if shape == "Asymmetric":
        slant = w * 0.22
        return [
            (x, y),
            (x + w - slant, y),
            (x + w, y + h / 2.0),
            (x + w - slant, y + h),
            (x, y + h),
        ]
    return None


def _point_polyline_distance(point, polygon):
    best = float("inf")
    n = len(polygon)
    for i in range(n):
        a = polygon[i]
        b = polygon[(i + 1) % n]
        best = min(best, point_segment_distance(point, a, b))
    return best


# Per-diagram arrowhead/marker insets: how far an edge path endpoint is
# legitimately pulled back from the node boundary to leave room for a marker.
# Class diagrams inset by the largest amount (the hollow inheritance triangle).
# Mirrors `src/edge_geometry.rs::arrowhead_inset`.
_CLASS_ARROW_INSET = {
    "OpenTriangle": 17.0,
    "ClassDependency": 5.0,
    None: 4.0,
}


def endpoint_boundary_tolerance(data, edge, which):
    """Allowed distance from a node boundary for an edge endpoint.

    Base tolerance is small (endpoints must sit on the boundary). When the
    endpoint carries an arrowhead/marker, the renderer insets the path to make
    room for it, so the tolerance is raised by that marker's inset. This keeps
    the off-boundary check honest about *visual* boundary contact rather than
    flagging the deliberately-inset path endpoint.
    """
    base = 1.5
    kind = str(data.get("kind", "")).strip().lower()
    if kind != "class":
        return base
    # `which` is "start" or "end"; class inheritance markers live at arrow_start.
    has_arrow = edge.get("arrow_start") if which == "start" else edge.get("arrow_end")
    if not has_arrow:
        return base
    arrow_kind = (
        edge.get("arrow_start_kind") if which == "start" else edge.get("arrow_end_kind")
    )
    inset = _CLASS_ARROW_INSET.get(arrow_kind, _CLASS_ARROW_INSET[None])
    # A small slack on top of the exact inset for rounding.
    return base + inset + 1.0


def point_shape_boundary_distance(point, node):
    """Distance from `point` to the node's *drawn* outline, shape-aware.

    For rectangles (and stadiums, which are rounded rects close enough for this
    tolerance check) this is the rect-edge distance. For inscribed shapes
    (diamond/circle/hexagon/...) it is distance to the actual outline, so an
    endpoint correctly placed on a diamond's slanted edge is not falsely
    reported as off-boundary."""
    shape = node.get("shape", "Rectangle")
    if shape in ("Circle", "DoubleCircle"):
        cx = node["x"] + node["width"] / 2.0
        cy = node["y"] + node["height"] / 2.0
        rx = max(node["width"] / 2.0, 1e-6)
        ry = max(node["height"] / 2.0, 1e-6)
        px, py = point
        # Distance from point to axis-aligned ellipse, scaled approximation.
        nx = (px - cx) / rx
        ny = (py - cy) / ry
        norm = math.hypot(nx, ny)
        if norm < 1e-9:
            return min(rx, ry)
        # Closest point on unit circle, mapped back, then Euclidean distance.
        closest = (cx + (nx / norm) * rx, cy + (ny / norm) * ry)
        return math.hypot(px - closest[0], py - closest[1])
    poly = _shape_polygon(node)
    if poly is not None:
        return _point_polyline_distance(point, poly)
    return point_rect_boundary_distance(point, node)


def segment_rect_overlap_length(a, b, rect, eps=1e-9):
    x, y, w, h = rect
    x1, y1 = a
    x2, y2 = b
    dx = x2 - x1
    dy = y2 - y1
    seg_len = math.hypot(dx, dy)
    if seg_len < eps:
        return 0.0

    t0 = 0.0
    t1 = 1.0
    for p, q in (
        (-dx, x1 - x),
        (dx, (x + w) - x1),
        (-dy, y1 - y),
        (dy, (y + h) - y1),
    ):
        if abs(p) < eps:
            if q < 0.0:
                return 0.0
            continue
        t = q / p
        if p < 0.0:
            if t > t1:
                return 0.0
            t0 = max(t0, t)
        else:
            if t < t0:
                return 0.0
            t1 = min(t1, t)

    if t1 <= t0:
        return 0.0
    return (t1 - t0) * seg_len


def layout_direction_axis(direction):
    token = str(direction or "").strip().lower()
    token = token.replace("-", "").replace("_", "")
    if token in {"leftright", "lr", "horizontal"}:
        return "x", 1.0
    if token in {"rightleft", "rl"}:
        return "x", -1.0
    if token in {"topdown", "tb", "td", "vertical", "topbottom"}:
        return "y", 1.0
    if token in {"bottomtop", "bt", "bu"}:
        return "y", -1.0
    return None, 0.0


def polyline_length(points):
    length = 0.0
    for a, b in segments_from_points(points):
        length += dist(a, b)
    return length


def point_on_polyline(points, fraction):
    if not points:
        return None
    if len(points) == 1:
        return points[0]
    f = clamp(fraction, 0.0, 1.0)
    total_len = polyline_length(points)
    if total_len < 1e-9:
        return points[0]
    target = total_len * f
    traversed = 0.0
    for a, b in segments_from_points(points):
        seg_len = dist(a, b)
        if seg_len < 1e-9:
            continue
        if traversed + seg_len >= target:
            t = (target - traversed) / seg_len
            return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
        traversed += seg_len
    return points[-1]


def sample_polyline(points, count=7, trim_ratio=0.08):
    if len(points) < 2:
        return []
    if count <= 0:
        return []
    start = clamp(trim_ratio, 0.0, 0.45)
    end = 1.0 - start
    if count == 1:
        p = point_on_polyline(points, 0.5)
        return [p] if p is not None else []
    samples = []
    for i in range(count):
        f = start + (end - start) * (i / (count - 1))
        p = point_on_polyline(points, f)
        if p is not None:
            samples.append(p)
    return samples


def point_segment_distance(point, a, b):
    vx = b[0] - a[0]
    vy = b[1] - a[1]
    seg_len_sq = vx * vx + vy * vy
    if seg_len_sq < 1e-12:
        return dist(point, a)
    t = ((point[0] - a[0]) * vx + (point[1] - a[1]) * vy) / seg_len_sq
    t = clamp(t, 0.0, 1.0)
    proj = (a[0] + vx * t, a[1] + vy * t)
    return dist(point, proj)


def point_polyline_distance(point, points):
    segments = segments_from_points(points)
    if not segments:
        return 0.0
    return min(point_segment_distance(point, a, b) for a, b in segments)


def pair_polyline_separation(points_a, points_b):
    samples_a = sample_polyline(points_a, count=7, trim_ratio=0.10)
    samples_b = sample_polyline(points_b, count=7, trim_ratio=0.10)
    if not samples_a or not samples_b:
        return None
    dist_a = sum(point_polyline_distance(point, points_b) for point in samples_a) / len(samples_a)
    dist_b = sum(point_polyline_distance(point, points_a) for point in samples_b) / len(samples_b)
    return 0.5 * (dist_a + dist_b)


def extract_subgraph_rects(data):
    rects = []
    for subgraph in data.get("subgraphs", []) or []:
        try:
            x = float(subgraph.get("x", 0.0))
            y = float(subgraph.get("y", 0.0))
            w = float(subgraph.get("width", 0.0))
            h = float(subgraph.get("height", 0.0))
        except (TypeError, ValueError):
            continue
        if w <= 1e-6 or h <= 1e-6:
            continue
        node_ids = {str(node_id) for node_id in (subgraph.get("nodes") or [])}
        if not node_ids:
            continue
        # An edge attached to the cluster itself (composite state / subgraph
        # used as an edge endpoint) must reach the cluster rect, so the
        # cluster's own id/label count as members for intrusion checks.
        for key in ("id", "label"):
            value = subgraph.get(key)
            if value:
                node_ids.add(str(value))
        rects.append((node_ids, (x, y, w, h)))
    return rects


def rect_contains(a, b, eps=1e-6, min_margin=1.0):
    ax1, ay1 = a["x"], a["y"]
    ax2, ay2 = ax1 + a["width"], ay1 + a["height"]
    bx1, by1 = b["x"], b["y"]
    bx2, by2 = bx1 + b["width"], by1 + b["height"]
    if bx1 < ax1 - eps or by1 < ay1 - eps or bx2 > ax2 + eps or by2 > ay2 + eps:
        return False
    left_margin = bx1 - ax1
    right_margin = ax2 - bx2
    top_margin = by1 - ay1
    bottom_margin = ay2 - by2
    # Require a visible margin so exact duplicates are still treated as overlaps.
    return (
        left_margin >= min_margin
        and right_margin >= min_margin
        and top_margin >= min_margin
        and bottom_margin >= min_margin
    )


def node_overlap_metrics(nodes, allow_containment=False):
    ids = list(nodes.keys())
    overlap_count = 0
    overlap_area = 0.0
    for i in range(len(ids)):
        a = nodes[ids[i]]
        ax1, ay1 = a["x"], a["y"]
        ax2, ay2 = ax1 + a["width"], ay1 + a["height"]
        for j in range(i + 1, len(ids)):
            b = nodes[ids[j]]
            bx1, by1 = b["x"], b["y"]
            bx2, by2 = bx1 + b["width"], by1 + b["height"]
            ix1 = max(ax1, bx1)
            iy1 = max(ay1, by1)
            ix2 = min(ax2, bx2)
            iy2 = min(ay2, by2)
            if ix2 > ix1 and iy2 > iy1:
                if allow_containment and (rect_contains(a, b) or rect_contains(b, a)):
                    continue
                overlap_count += 1
                overlap_area += (ix2 - ix1) * (iy2 - iy1)
    return overlap_count, overlap_area


def segment_intersects_rect(a, b, rect, eps=1e-6):
    x, y, w, h = rect
    x1, y1 = a
    x2, y2 = b
    min_x = min(x1, x2)
    max_x = max(x1, x2)
    min_y = min(y1, y2)
    max_y = max(y1, y2)
    if max_x < x - eps or min_x > x + w + eps or max_y < y - eps or min_y > y + h + eps:
        return False
    if x - eps <= x1 <= x + w + eps and y - eps <= y1 <= y + h + eps:
        return True
    if x - eps <= x2 <= x + w + eps and y - eps <= y2 <= y + h + eps:
        return True
    corners = [
        (x, y),
        (x + w, y),
        (x + w, y + h),
        (x, y + h),
    ]
    edges = [
        (corners[0], corners[1]),
        (corners[1], corners[2]),
        (corners[2], corners[3]),
        (corners[3], corners[0]),
    ]
    for c, d in edges:
        if segments_intersect(a, b, c, d, eps=eps):
            return True
    return False


def crossing_angle_degrees(a, b, c, d):
    v1 = (b[0] - a[0], b[1] - a[1])
    v2 = (d[0] - c[0], d[1] - c[1])
    l1 = math.hypot(v1[0], v1[1])
    l2 = math.hypot(v2[0], v2[1])
    if l1 < 1e-9 or l2 < 1e-9:
        return 90.0
    # Use acute crossing angle as readability proxy.
    cosv = abs((v1[0] * v2[0] + v1[1] * v2[1]) / (l1 * l2))
    cosv = clamp(cosv, -1.0, 1.0)
    return math.degrees(math.acos(cosv))


def direction_from_points(a, b):
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    length = math.hypot(dx, dy)
    if length < 1e-9:
        return None
    return (dx / length, dy / length)


def min_angular_resolution_penalty(node_dirs):
    if len(node_dirs) < 2:
        return None
    min_angle = 180.0
    for i in range(len(node_dirs)):
        for j in range(i + 1, len(node_dirs)):
            a = node_dirs[i]
            b = node_dirs[j]
            dot = clamp(a[0] * b[0] + a[1] * b[1], -1.0, 1.0)
            angle = math.degrees(math.acos(dot))
            if angle < min_angle:
                min_angle = angle
    penalty = max(0.0, (35.0 - min_angle) / 35.0)
    return min_angle, penalty


def compute_content_bounds(nodes, edges):
    min_x = float("inf")
    min_y = float("inf")
    max_x = float("-inf")
    max_y = float("-inf")
    seen = False

    for node in nodes.values():
        x1 = node["x"]
        y1 = node["y"]
        x2 = x1 + node["width"]
        y2 = y1 + node["height"]
        min_x = min(min_x, x1)
        min_y = min(min_y, y1)
        max_x = max(max_x, x2)
        max_y = max(max_y, y2)
        seen = True

    for edge in edges:
        for point in edge.get("points", []):
            px, py = point
            min_x = min(min_x, px)
            min_y = min(min_y, py)
            max_x = max(max_x, px)
            max_y = max(max_y, py)
            seen = True

    if not seen:
        return 0.0, 0.0, 0.0, 0.0
    return min_x, min_y, max_x, max_y


def connected_components(nodes, edges):
    adjacency = {node_id: set() for node_id in nodes}
    for edge in edges:
        from_id = edge.get("from")
        to_id = edge.get("to")
        if from_id in adjacency and to_id in adjacency:
            adjacency[from_id].add(to_id)
            adjacency[to_id].add(from_id)

    comps = []
    seen = set()
    for node_id in adjacency:
        if node_id in seen:
            continue
        stack = [node_id]
        seen.add(node_id)
        comp = []
        while stack:
            cur = stack.pop()
            comp.append(cur)
            for nxt in adjacency[cur]:
                if nxt in seen:
                    continue
                seen.add(nxt)
                stack.append(nxt)
        comps.append(comp)
    return comps


def compute_metrics(data, nodes, edges):
    kind = str(data.get("kind", "")).strip().lower()
    flow_axis, flow_sign = layout_direction_axis(data.get("direction", ""))
    total_edge_length = 0.0
    edge_bends = 0
    edge_crossings = 0
    edge_overlap_length = 0.0
    port_congestion = 0
    edge_node_crossings = 0
    edge_node_crossing_length = 0.0
    edge_detour_sum = 0.0
    edge_detour_count = 0
    crossing_angle_penalty = 0.0
    crossing_count_with_angle = 0
    endpoint_boundary_error_sum = 0.0
    endpoint_boundary_error_count = 0
    endpoint_off_boundary_count = 0
    port_target_side_mismatch_count = 0
    port_target_side_comparable = 0
    port_direction_misalignment_count = 0
    port_direction_comparable = 0
    flow_forward_length = 0.0
    flow_backtrack_length = 0.0
    flow_lateral_length = 0.0
    flow_backtracking_edge_count = 0
    flow_monotonic_edge_count = 0

    segments = []
    edge_points = []
    edge_path_lengths = []
    edge_node_near_miss_pairs = set()
    node_dirs = {}
    subgraph_rects = extract_subgraph_rects(data)
    subgraph_boundary_intrusion_pairs = 0
    subgraph_boundary_intrusion_length = 0.0
    parallel_edge_pair_count = 0
    parallel_edge_overlap_pair_count = 0
    parallel_edge_overlap_ratios = []
    parallel_edge_separations = []

    # Semantic containment: a node's rendered box must not sit inside a
    # subgraph box it is not a member of (foreign containment), and a member
    # node must not spill outside its own subgraph box (member escape).
    # Both misstate the declared containment structure of the diagram.
    containment_foreign_node_count = 0
    containment_member_escape_count = 0
    containment_overlap_area = 0.0
    if subgraph_rects:
        raw_subgraphs = data.get("subgraphs", []) or []
        anchor_names = set()
        for subgraph in raw_subgraphs:
            for key in ("id", "label"):
                value = subgraph.get(key)
                if value:
                    anchor_names.add(str(value))
        for node in nodes.values():
            node_id = str(node.get("id"))
            if node_id in anchor_names:
                continue
            try:
                nx1 = float(node["x"])
                ny1 = float(node["y"])
                nx2 = nx1 + float(node["width"])
                ny2 = ny1 + float(node["height"])
            except (KeyError, TypeError, ValueError):
                continue
            node_area = max(nx2 - nx1, 0.0) * max(ny2 - ny1, 0.0)
            for member_nodes, (rx, ry, rw, rh) in subgraph_rects:
                ox = min(nx2, rx + rw) - max(nx1, rx)
                oy = min(ny2, ry + rh) - max(ny1, ry)
                overlap = max(ox, 0.0) * max(oy, 0.0)
                is_member = node_id in member_nodes
                if is_member:
                    # Member escape: meaningful part of the node outside its box.
                    if node_area > 0.0 and overlap < node_area * 0.995:
                        containment_member_escape_count += 1
                        containment_overlap_area += node_area - overlap
                else:
                    # Foreign containment: meaningful overlap with a box the
                    # node does not belong to (2px sliver tolerance).
                    if overlap > 4.0 and ox > 2.0 and oy > 2.0:
                        containment_foreign_node_count += 1
                        containment_overlap_area += overlap

    # Text clipping: for box-shaped diagram kinds the measured label block
    # must fit inside the node box, and every visible node must fit on the
    # canvas. Kinds that legitimately draw labels outside the node shape
    # (sankey bars, architecture icons, ...) are excluded in the gate layer.
    label_overflow_count = 0
    label_overflow_area = 0.0
    canvas_overflow_count = 0
    canvas_w = float(data.get("width", 0.0) or 0.0)
    canvas_h = float(data.get("height", 0.0) or 0.0)
    for node in nodes.values():
        node_id = str(node.get("id"))
        # State pseudostate markers carry the state name as metadata but
        # render as small circles/bars without inline text.
        if node_id.startswith("__start_") or node_id.startswith("__end_"):
            continue
        lw = float(node.get("label_width", 0.0) or 0.0)
        lh = float(node.get("label_height", 0.0) or 0.0)
        w = node["width"]
        h = node["height"]
        lines = node.get("label_lines") or []
        has_text = any(str(line).strip() for line in lines)
        if has_text and (lw > w + 1.0 or lh > h + 1.0):
            label_overflow_count += 1
            label_overflow_area += max(lw - w, 0.0) * max(lh, 1.0) + max(lh - h, 0.0) * max(
                lw, 1.0
            )
        if canvas_w > 0.0 and canvas_h > 0.0:
            if (
                node["x"] < -1.0
                or node["y"] < -1.0
                or node["x"] + w > canvas_w + 1.0
                or node["y"] + h > canvas_h + 1.0
            ):
                canvas_overflow_count += 1

    for idx, edge in enumerate(edges):
        points = [tuple(p) for p in edge.get("points", [])]
        edge_points.append(points)
        edge_bends += bend_count(points)
        path_len = 0.0
        edge_forward = 0.0
        edge_backtrack = 0.0
        edge_lateral = 0.0
        for a, b in segments_from_points(points):
            seg_len = dist(a, b)
            path_len += seg_len
            total_edge_length += seg_len
            segments.append((idx, a, b))
            if flow_axis:
                primary_delta = (b[0] - a[0]) if flow_axis == "x" else (b[1] - a[1])
                signed = primary_delta * flow_sign
                edge_forward += max(0.0, signed)
                edge_backtrack += max(0.0, -signed)
                edge_lateral += max(0.0, seg_len - abs(primary_delta))
        edge_path_lengths.append(path_len)
        if len(points) >= 2:
            from_id = edge.get("from")
            to_id = edge.get("to")
            direct_len = dist(points[0], points[-1])
            if direct_len > 1e-3:
                edge_detour_sum += path_len / direct_len
                edge_detour_count += 1
            if flow_axis and from_id in nodes and to_id in nodes:
                src_center = node_center(nodes[from_id])
                dst_center = node_center(nodes[to_id])
                desired_primary = (
                    (dst_center[0] - src_center[0]) if flow_axis == "x" else (dst_center[1] - src_center[1])
                ) * flow_sign
                if desired_primary > 1e-6:
                    flow_monotonic_edge_count += 1
                    flow_forward_length += edge_forward
                    flow_backtrack_length += edge_backtrack
                    flow_lateral_length += edge_lateral
                    if edge_backtrack > 1e-6:
                        flow_backtracking_edge_count += 1
            start_dir = direction_from_points(points[0], points[1])
            end_dir = direction_from_points(points[-1], points[-2])
            if from_id and start_dir is not None:
                node_dirs.setdefault(from_id, []).append(start_dir)
            if to_id and end_dir is not None:
                node_dirs.setdefault(to_id, []).append(end_dir)

    for i in range(len(segments)):
        ei, a1, a2 = segments[i]
        edge = edges[ei]
        from_id = edge.get("from")
        to_id = edge.get("to")
        for node_id, node in nodes.items():
            if node_id == from_id or node_id == to_id:
                continue
            rect = (node["x"], node["y"], node["width"], node["height"])
            if segment_intersects_rect(a1, a2, rect):
                edge_node_crossings += 1
                edge_node_crossing_length += segment_rect_overlap_length(a1, a2, rect)
        for j in range(i + 1, len(segments)):
            ej, b1, b2 = segments[j]
            if ei == ej:
                continue
            if dist(a1, b1) < 1e-6 or dist(a1, b2) < 1e-6 or dist(a2, b1) < 1e-6 or dist(a2, b2) < 1e-6:
                continue
            if segments_intersect(a1, a2, b1, b2):
                edge_crossings += 1
                crossing_count_with_angle += 1
                angle = crossing_angle_degrees(a1, a2, b1, b2)
                crossing_angle_penalty += max(0.0, (35.0 - angle) / 35.0)
            edge_overlap_length += collinear_overlap_length(a1, a2, b1, b2)

    port_counts = {node_id: {"left": 0, "right": 0, "top": 0, "bottom": 0} for node_id in nodes}
    for edge, points in zip(edges, edge_points):
        if len(points) < 2:
            continue
        from_id = edge.get("from")
        to_id = edge.get("to")
        from_side_eval = "unknown"
        to_side_eval = "unknown"
        if from_id in nodes:
            from_node = nodes[from_id]
            side = infer_side(from_node, points[0])
            if side in port_counts[from_id]:
                port_counts[from_id][side] += 1
            tol = max(1.0, min(from_node["width"], from_node["height"]) * 0.04)
            from_side_eval = infer_side(from_node, points[0], tol=tol)
            boundary_error = point_shape_boundary_distance(points[0], from_node)
            endpoint_boundary_error_sum += boundary_error
            endpoint_boundary_error_count += 1
            if boundary_error > endpoint_boundary_tolerance(data, edge, "start"):
                endpoint_off_boundary_count += 1

            exit_side = dominant_axis_side(
                points[1][0] - points[0][0],
                points[1][1] - points[0][1],
            )
            if from_side_eval != "unknown" and exit_side is not None:
                port_direction_comparable += 1
                if exit_side != from_side_eval:
                    port_direction_misalignment_count += 1
        if to_id in nodes:
            to_node = nodes[to_id]
            side = infer_side(to_node, points[-1])
            if side in port_counts[to_id]:
                port_counts[to_id][side] += 1
            tol = max(1.0, min(to_node["width"], to_node["height"]) * 0.04)
            to_side_eval = infer_side(to_node, points[-1], tol=tol)
            boundary_error = point_shape_boundary_distance(points[-1], to_node)
            endpoint_boundary_error_sum += boundary_error
            endpoint_boundary_error_count += 1
            if boundary_error > endpoint_boundary_tolerance(data, edge, "end"):
                endpoint_off_boundary_count += 1

            enter_side = dominant_axis_side(
                points[-1][0] - points[-2][0],
                points[-1][1] - points[-2][1],
            )
            expected_enter_side = opposite_side(to_side_eval)
            if expected_enter_side is not None and enter_side is not None:
                port_direction_comparable += 1
                if enter_side != expected_enter_side:
                    port_direction_misalignment_count += 1

        if from_id in nodes and to_id in nodes:
            expected_from_side = expected_side_towards(nodes[from_id], nodes[to_id])
            if expected_from_side is not None:
                port_target_side_comparable += 1
                if from_side_eval != expected_from_side:
                    port_target_side_mismatch_count += 1
            expected_to_side = expected_side_towards(nodes[to_id], nodes[from_id])
            if expected_to_side is not None:
                port_target_side_comparable += 1
                if to_side_eval != expected_to_side:
                    port_target_side_mismatch_count += 1

    for counts in port_counts.values():
        for count in counts.values():
            if count > 1:
                port_congestion += count - 1

    if subgraph_rects:
        for edge, points in zip(edges, edge_points):
            if len(points) < 2:
                continue
            from_id = edge.get("from")
            to_id = edge.get("to")
            from_key = str(from_id) if from_id is not None else ""
            to_key = str(to_id) if to_id is not None else ""
            for member_nodes, rect in subgraph_rects:
                if from_key in member_nodes or to_key in member_nodes:
                    continue
                overlap_len = 0.0
                for a, b in segments_from_points(points):
                    overlap_len += segment_rect_overlap_length(a, b, rect)
                if overlap_len > 1e-6:
                    subgraph_boundary_intrusion_pairs += 1
                    subgraph_boundary_intrusion_length += overlap_len

    parallel_groups = {}
    for idx, edge in enumerate(edges):
        from_id = edge.get("from")
        to_id = edge.get("to")
        if from_id is None or to_id is None:
            continue
        key = tuple(sorted((str(from_id), str(to_id))))
        parallel_groups.setdefault(key, []).append(idx)

    for group_edges in parallel_groups.values():
        if len(group_edges) < 2:
            continue
        for i in range(len(group_edges)):
            for j in range(i + 1, len(group_edges)):
                ia = group_edges[i]
                ib = group_edges[j]
                points_a = edge_points[ia]
                points_b = edge_points[ib]
                if len(points_a) < 2 or len(points_b) < 2:
                    continue
                parallel_edge_pair_count += 1
                overlap_len = 0.0
                for a1, a2 in segments_from_points(points_a):
                    for b1, b2 in segments_from_points(points_b):
                        overlap_len += collinear_overlap_length(a1, a2, b1, b2)
                min_len = max(min(edge_path_lengths[ia], edge_path_lengths[ib]), 1e-6)
                overlap_ratio = clamp(overlap_len / min_len, 0.0, 1.0)
                parallel_edge_overlap_ratios.append(overlap_ratio)
                if overlap_ratio > 0.25:
                    parallel_edge_overlap_pair_count += 1
                separation = pair_polyline_separation(points_a, points_b)
                if separation is not None:
                    parallel_edge_separations.append(separation)

    node_ids = list(nodes.keys())
    node_spacing_violation_count = 0
    node_spacing_violation_severity = 0.0
    median_node_span = 0.0
    if node_ids:
        spans = []
        for node in nodes.values():
            spans.append(min(max(node["width"], 0.0), max(node["height"], 0.0)))
        spans = sorted(spans)
        median_node_span = spans[len(spans) // 2]
    spacing_target = clamp(median_node_span * 0.25 if median_node_span > 0.0 else 12.0, 8.0, 24.0)
    for i in range(len(node_ids)):
        a = nodes[node_ids[i]]
        ax1, ay1 = a["x"], a["y"]
        ax2, ay2 = ax1 + a["width"], ay1 + a["height"]
        for j in range(i + 1, len(node_ids)):
            b = nodes[node_ids[j]]
            bx1, by1 = b["x"], b["y"]
            bx2, by2 = bx1 + b["width"], by1 + b["height"]
            if ax1 < bx2 and bx1 < ax2 and ay1 < by2 and by1 < ay2:
                # Overlap is handled by node overlap metrics.
                continue
            gap_x = max(0.0, max(bx1 - ax2, ax1 - bx2))
            gap_y = max(0.0, max(by1 - ay2, ay1 - by2))
            gap = math.hypot(gap_x, gap_y)
            if gap < spacing_target:
                node_spacing_violation_count += 1
                node_spacing_violation_severity += (spacing_target - gap) / max(spacing_target, 1e-6)

    near_miss_pad = max(4.0, spacing_target * 0.5)
    for ei, a1, a2 in segments:
        edge = edges[ei]
        from_id = edge.get("from")
        to_id = edge.get("to")
        for node_id, node in nodes.items():
            if node_id == from_id or node_id == to_id:
                continue
            rect = (node["x"], node["y"], node["width"], node["height"])
            if segment_intersects_rect(a1, a2, rect):
                continue
            padded = (
                rect[0] - near_miss_pad,
                rect[1] - near_miss_pad,
                rect[2] + 2.0 * near_miss_pad,
                rect[3] + 2.0 * near_miss_pad,
            )
            if segment_intersects_rect(a1, a2, padded):
                edge_node_near_miss_pairs.add((ei, node_id))

    angular_resolution_penalty = 0.0
    low_angular_resolution_nodes = 0
    min_angular_resolution = 180.0
    for dirs in node_dirs.values():
        result = min_angular_resolution_penalty(dirs)
        if result is None:
            continue
        angle, penalty = result
        min_angular_resolution = min(min_angular_resolution, angle)
        angular_resolution_penalty += penalty
        if penalty > 0.0:
            low_angular_resolution_nodes += 1

    allow_containment = kind == "treemap"
    overlap_count, overlap_area = node_overlap_metrics(nodes, allow_containment=allow_containment)
    node_area_total = sum(
        max(0.0, node["width"]) * max(0.0, node["height"]) for node in nodes.values()
    )
    width = data.get("width", 0.0) or 0.0
    height = data.get("height", 0.0) or 0.0
    layout_area = width * height
    node_count = len(nodes)
    edge_count = len(edges)

    min_x, min_y, max_x, max_y = compute_content_bounds(nodes, edges)
    content_width = max(0.0, max_x - min_x)
    content_height = max(0.0, max_y - min_y)
    content_bbox_area = content_width * content_height
    content_fill_ratio = safe_ratio(content_bbox_area, layout_area, default=0.0)
    # Keep bounded so pathological inputs (e.g. wrong canvas metadata) do not explode scores.
    content_fill_ratio = max(0.0, min(1.2, content_fill_ratio))
    wasted_space_ratio = max(0.0, 1.0 - min(1.0, content_fill_ratio))

    target_fill = 0.60
    space_efficiency_penalty = max(0.0, target_fill - content_fill_ratio)
    # Large-diagram emphasis for whitespace waste:
    # small diagrams get near-zero weight; large dense canvases get full weight.
    large_node_weight = smoothstep_ramp(node_count, 14, 70)
    large_edge_weight = smoothstep_ramp(edge_count, 18, 130)
    large_area_weight = smoothstep_ramp(layout_area, 300000.0, 2200000.0)
    structural_weight = max(large_node_weight, large_edge_weight)
    large_diagram_space_weight = clamp(
        large_area_weight * 0.60 + structural_weight * 0.40,
        0.0,
        1.0,
    )
    wasted_space_large_ratio = wasted_space_ratio * large_diagram_space_weight
    space_efficiency_large_penalty = (
        space_efficiency_penalty * large_diagram_space_weight
    )

    left_margin = max(0.0, min_x)
    right_margin = max(0.0, width - max_x)
    top_margin = max(0.0, min_y)
    bottom_margin = max(0.0, height - max_y)
    margin_imbalance_ratio = safe_ratio(abs(left_margin - right_margin), max(width, 1.0), default=0.0)
    margin_imbalance_ratio += safe_ratio(
        abs(top_margin - bottom_margin), max(height, 1.0), default=0.0
    )

    avg_edge_detour_ratio = (
        edge_detour_sum / edge_detour_count if edge_detour_count > 0 else 1.0
    )
    edge_detour_penalty = max(0.0, avg_edge_detour_ratio - 1.30)
    edge_length_per_node = safe_ratio(total_edge_length, max(node_count, 1), default=0.0)

    components = connected_components(nodes, edges)
    component_count = len(components)
    disconnected_components = max(0, component_count - 1)
    component_bbox_area_sum = 0.0
    component_areas = []
    for comp in components:
        c_min_x = float("inf")
        c_min_y = float("inf")
        c_max_x = float("-inf")
        c_max_y = float("-inf")
        for node_id in comp:
            node = nodes[node_id]
            x1 = node["x"]
            y1 = node["y"]
            x2 = x1 + node["width"]
            y2 = y1 + node["height"]
            c_min_x = min(c_min_x, x1)
            c_min_y = min(c_min_y, y1)
            c_max_x = max(c_max_x, x2)
            c_max_y = max(c_max_y, y2)
        if c_max_x > c_min_x and c_max_y > c_min_y:
            area = (c_max_x - c_min_x) * (c_max_y - c_min_y)
            component_bbox_area_sum += area
            component_areas.append(area)

    component_gap_ratio = max(
        0.0,
        1.0 - safe_ratio(component_bbox_area_sum, max(content_bbox_area, 1e-6), default=0.0),
    )
    component_gap_large_ratio = component_gap_ratio * large_diagram_space_weight
    component_balance_penalty = 0.0
    if len(component_areas) > 1:
        total_component_area = sum(component_areas)
        if total_component_area > 1e-9:
            shares = [area / total_component_area for area in component_areas]
            entropy = 0.0
            for share in shares:
                if share > 1e-12:
                    entropy -= share * math.log(share)
            max_entropy = math.log(len(shares))
            if max_entropy > 1e-12:
                component_balance_penalty = 1.0 - (entropy / max_entropy)

    content_aspect_ratio = safe_ratio(content_width, max(content_height, 1e-6), default=1.0)
    content_aspect_elongation = max(
        content_aspect_ratio,
        safe_ratio(1.0, max(content_aspect_ratio, 1e-6), default=1.0),
    )
    content_center_x = (min_x + max_x) * 0.5
    content_center_y = (min_y + max_y) * 0.5
    canvas_center_x = width * 0.5
    canvas_center_y = height * 0.5
    content_center_offset_ratio = safe_ratio(
        dist((content_center_x, content_center_y), (canvas_center_x, canvas_center_y)),
        max(math.hypot(width, height), 1.0),
        default=0.0,
    )
    overflow_x = max(0.0, -min_x) + max(0.0, max_x - width)
    overflow_y = max(0.0, -min_y) + max(0.0, max_y - height)
    content_overflow_ratio = safe_ratio(overflow_x, max(width, 1.0), 0.0) + safe_ratio(
        overflow_y, max(height, 1.0), 0.0
    )

    layout_area_per_node = safe_ratio(layout_area, max(node_count, 1), default=0.0)
    layout_area_per_edge = safe_ratio(layout_area, max(edge_count, 1), default=0.0)
    node_fill_ratio = safe_ratio(node_area_total, content_bbox_area, default=0.0)
    endpoint_boundary_error_mean = safe_ratio(
        endpoint_boundary_error_sum,
        max(endpoint_boundary_error_count, 1),
        default=0.0,
    )
    endpoint_off_boundary_ratio = safe_ratio(
        endpoint_off_boundary_count,
        max(endpoint_boundary_error_count, 1),
        default=0.0,
    )
    port_target_side_mismatch_ratio = safe_ratio(
        port_target_side_mismatch_count,
        max(port_target_side_comparable, 1),
        default=0.0,
    )
    port_direction_misalignment_ratio = safe_ratio(
        port_direction_misalignment_count,
        max(port_direction_comparable, 1),
        default=0.0,
    )
    edge_node_crossing_length_per_edge = safe_ratio(
        edge_node_crossing_length,
        max(edge_count, 1),
        default=0.0,
    )
    edge_crossings_per_edge = safe_ratio(
        edge_crossings,
        max(edge_count, 1),
        default=0.0,
    )
    subgraph_boundary_intrusion_ratio = safe_ratio(
        subgraph_boundary_intrusion_pairs,
        max(edge_count, 1),
        default=0.0,
    )
    subgraph_boundary_intrusion_length_per_edge = safe_ratio(
        subgraph_boundary_intrusion_length,
        max(edge_count, 1),
        default=0.0,
    )
    parallel_edge_overlap_ratio_mean = (
        sum(parallel_edge_overlap_ratios) / len(parallel_edge_overlap_ratios)
        if parallel_edge_overlap_ratios
        else 0.0
    )
    parallel_edge_overlap_pair_ratio = safe_ratio(
        parallel_edge_overlap_pair_count,
        max(parallel_edge_pair_count, 1),
        default=0.0,
    )
    parallel_edge_separation_mean = (
        sum(parallel_edge_separations) / len(parallel_edge_separations)
        if parallel_edge_separations
        else 0.0
    )
    parallel_edge_separation_threshold = max(4.0, spacing_target * 0.6)
    parallel_edge_separation_bad_count = sum(
        1 for sep in parallel_edge_separations if sep < parallel_edge_separation_threshold
    )
    parallel_edge_separation_bad_ratio = safe_ratio(
        parallel_edge_separation_bad_count,
        max(len(parallel_edge_separations), 1),
        default=0.0,
    )
    flow_primary_length = flow_forward_length + flow_backtrack_length
    flow_backtrack_ratio = safe_ratio(
        flow_backtrack_length,
        max(flow_primary_length, 1e-6),
        default=0.0,
    )
    flow_monotonicity_score = 1.0 - flow_backtrack_ratio
    flow_backtracking_edge_ratio = safe_ratio(
        flow_backtracking_edge_count,
        max(flow_monotonic_edge_count, 1),
        default=0.0,
    )
    flow_lateral_ratio = safe_ratio(
        flow_lateral_length,
        max(total_edge_length, 1e-6),
        default=0.0,
    )

    return {
        "node_count": node_count,
        "edge_count": edge_count,
        "edge_crossings": edge_crossings,
        "edge_crossings_per_edge": edge_crossings_per_edge,
        "edge_node_crossings": edge_node_crossings,
        "edge_node_crossing_length": edge_node_crossing_length,
        "edge_node_crossing_length_per_edge": edge_node_crossing_length_per_edge,
        "subgraph_boundary_intrusion_pairs": subgraph_boundary_intrusion_pairs,
        "subgraph_boundary_intrusion_ratio": subgraph_boundary_intrusion_ratio,
        "subgraph_boundary_intrusion_length": subgraph_boundary_intrusion_length,
        "subgraph_boundary_intrusion_length_per_edge": subgraph_boundary_intrusion_length_per_edge,
        "total_edge_length": total_edge_length,
        "edge_length_per_node": edge_length_per_node,
        "edge_bends": edge_bends,
        "port_congestion": port_congestion,
        "port_target_side_mismatch_count": port_target_side_mismatch_count,
        "port_target_side_mismatch_ratio": port_target_side_mismatch_ratio,
        "port_direction_misalignment_count": port_direction_misalignment_count,
        "port_direction_misalignment_ratio": port_direction_misalignment_ratio,
        "endpoint_boundary_error_mean": endpoint_boundary_error_mean,
        "endpoint_off_boundary_count": endpoint_off_boundary_count,
        "endpoint_off_boundary_ratio": endpoint_off_boundary_ratio,
        "parallel_edge_pair_count": parallel_edge_pair_count,
        "parallel_edge_overlap_pair_count": parallel_edge_overlap_pair_count,
        "parallel_edge_overlap_pair_ratio": parallel_edge_overlap_pair_ratio,
        "parallel_edge_overlap_ratio_mean": parallel_edge_overlap_ratio_mean,
        "parallel_edge_separation_mean": parallel_edge_separation_mean,
        "parallel_edge_separation_bad_count": parallel_edge_separation_bad_count,
        "parallel_edge_separation_bad_ratio": parallel_edge_separation_bad_ratio,
        "parallel_edge_separation_threshold": parallel_edge_separation_threshold,
        "flow_forward_length": flow_forward_length,
        "flow_backtrack_length": flow_backtrack_length,
        "flow_lateral_length": flow_lateral_length,
        "flow_backtrack_ratio": flow_backtrack_ratio,
        "flow_monotonicity_score": flow_monotonicity_score,
        "flow_monotonic_edge_count": flow_monotonic_edge_count,
        "flow_backtracking_edge_count": flow_backtracking_edge_count,
        "flow_backtracking_edge_ratio": flow_backtracking_edge_ratio,
        "flow_lateral_ratio": flow_lateral_ratio,
        "edge_overlap_length": edge_overlap_length,
        "crossing_angle_penalty": crossing_angle_penalty,
        "crossing_count_with_angle": crossing_count_with_angle,
        "avg_crossing_angle_penalty": safe_ratio(crossing_angle_penalty, max(crossing_count_with_angle, 1), 0.0),
        "avg_edge_detour_ratio": avg_edge_detour_ratio,
        "edge_detour_penalty": edge_detour_penalty,
        "edge_node_near_miss_count": len(edge_node_near_miss_pairs),
        "layout_area": layout_area,
        "layout_area_per_node": layout_area_per_node,
        "layout_area_per_edge": layout_area_per_edge,
        "node_area_total": node_area_total,
        "node_fill_ratio": node_fill_ratio,
        "content_min_x": min_x,
        "content_min_y": min_y,
        "content_max_x": max_x,
        "content_max_y": max_y,
        "content_width": content_width,
        "content_height": content_height,
        "content_bbox_area": content_bbox_area,
        "content_aspect_ratio": content_aspect_ratio,
        "content_aspect_elongation": content_aspect_elongation,
        "content_fill_ratio": content_fill_ratio,
        "wasted_space_ratio": wasted_space_ratio,
        "space_efficiency_penalty": space_efficiency_penalty,
        "large_diagram_space_weight": large_diagram_space_weight,
        "wasted_space_large_ratio": wasted_space_large_ratio,
        "space_efficiency_large_penalty": space_efficiency_large_penalty,
        "content_center_offset_ratio": content_center_offset_ratio,
        "content_overflow_ratio": content_overflow_ratio,
        "component_count": component_count,
        "disconnected_components": disconnected_components,
        "component_bbox_area_sum": component_bbox_area_sum,
        "component_gap_ratio": component_gap_ratio,
        "component_gap_large_ratio": component_gap_large_ratio,
        "component_balance_penalty": component_balance_penalty,
        "node_spacing_target": spacing_target,
        "node_spacing_violation_count": node_spacing_violation_count,
        "node_spacing_violation_severity": node_spacing_violation_severity,
        "angular_resolution_penalty": angular_resolution_penalty,
        "low_angular_resolution_nodes": low_angular_resolution_nodes,
        "min_angular_resolution_deg": min_angular_resolution if min_angular_resolution < 180.0 else 180.0,
        "margin_left": left_margin,
        "margin_right": right_margin,
        "margin_top": top_margin,
        "margin_bottom": bottom_margin,
        "margin_imbalance_ratio": margin_imbalance_ratio,
        "node_overlap_count": overlap_count,
        "node_overlap_area": overlap_area,
        "containment_foreign_node_count": containment_foreign_node_count,
        "containment_member_escape_count": containment_member_escape_count,
        "containment_overlap_area": containment_overlap_area,
        "label_overflow_count": label_overflow_count,
        "label_overflow_area": label_overflow_area,
        "canvas_overflow_count": canvas_overflow_count,
    }


def weighted_score(metrics):
    score = 0.0
    for key, weight in WEIGHTS.items():
        score += metrics.get(key, 0.0) * weight
    return score


def main():
    parser = argparse.ArgumentParser(description="Score layout dumps for objective metrics")
    parser.add_argument("--input", required=True, help="layout dump file or directory")
    parser.add_argument("--output", default="", help="write JSON summary to file")
    args = parser.parse_args()

    input_path = Path(args.input)
    if input_path.is_dir():
        files = sorted(input_path.glob("**/*-layout.json"))
    else:
        files = [input_path]

    results = {}
    for path in files:
        data, nodes, edges = load_layout(path)
        metrics = compute_metrics(data, nodes, edges)
        metrics["score"] = weighted_score(metrics)
        results[path.name] = metrics

    if args.output:
        Path(args.output).write_text(json.dumps(results, indent=2))
    else:
        print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
