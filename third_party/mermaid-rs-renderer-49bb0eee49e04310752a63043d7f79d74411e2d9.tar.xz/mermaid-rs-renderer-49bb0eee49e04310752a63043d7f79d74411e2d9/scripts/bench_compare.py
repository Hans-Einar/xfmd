#!/usr/bin/env python3
"""
Benchmark comparison script for mmdr vs mermaid-cli.

Features:
- Pipeline breakdown (parse/layout/render times)
- Memory usage tracking
- Visual SVG chart generation
"""
import argparse
import json
import os
import re
import shlex
import statistics
import subprocess
import sys
import time
import datetime
import concurrent.futures
import getpass
import hashlib
import platform
import shutil
import socket
from pathlib import Path
from typing import Optional


def find_puppeteer_chrome() -> Optional[str]:
    base = Path.home() / ".cache" / "puppeteer" / "chrome"
    if not base.exists():
        return None
    candidates = sorted(base.glob("**/chrome"))
    return str(candidates[-1]) if candidates else None


ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "benches" / "fixtures"

BIN = os.environ.get("MMDR_BIN", str(ROOT / "target" / "release" / "mmdr"))
MMD_CLI = os.environ.get("MMD_CLI", "npx -y @mermaid-js/mermaid-cli")
RUNS = int(os.environ.get("RUNS", "8"))
WARMUP = int(os.environ.get("WARMUP", "2"))
MMDR_MEASURE_MEMORY = False
MMD_CLI_RUNS = int(os.environ.get("MMD_CLI_RUNS", "1"))
MMD_CLI_WARMUP = int(os.environ.get("MMD_CLI_WARMUP", "0"))
MMDR_JOBS = int(
    os.environ.get("MMDR_JOBS", str(max(1, min(4, os.cpu_count() or 1))))
)
MMD_CLI_JOBS = int(
    os.environ.get("MMD_CLI_JOBS", str(max(1, min(4, os.cpu_count() or 1))))
)
MMD_CLI_MEASURE_MEMORY = False
MMDC_CONFIG = os.environ.get("MMDC_CONFIG", "")
HISTORY_LOG = Path(
    os.environ.get(
        "HISTORY_LOG",
        str(ROOT / "tmp" / "benchmark-history" / "bench-compare-runs.jsonl"),
    )
)
MMDC_CACHE_SCHEMA_VERSION = 2

CASE_NAMES = [
    "flowchart_small",
    "flowchart_medium",
    "flowchart_large",
    "flowchart_tiny",
    "flowchart_ports_heavy",
    "flowchart_weave",
    "flowchart_backedges_subgraphs",
    "flowchart_sparse_components",
    "flowchart_lanes_crossfeed",
    "flowchart_grid_feedback",
    "flowchart_fanout_returns",
    "flowchart_label_collision",
    "flowchart_nested_clusters",
    "flowchart_asymmetric_components",
    "flowchart_parallel_merges",
    "flowchart_long_edge_labels",
    "flowchart_selfloop_bidi",
    "flowchart_component_packing",
    "flowchart_direction_conflict",
    "flowchart_parallel_label_stack",
    "flowchart_port_alignment_matrix",
    "flowchart_path_occlusion_maze",
    "flowchart_subgraph_boundary_intrusion",
    "flowchart_parallel_edges_bundle",
    "flowchart_flow_direction_backtrack",
    "flowchart_mega_multihub_control",
    "flowchart_mega_crosslane_subgraphs",
    "flowchart_mega_braid_feedback",
    "flowchart_mega_event_mesh",
    "flowchart_mega_nested_regions",
    "class_medium",
    "state_medium",
    "sequence_medium",
    "er_medium",
    "pie_medium",
    "mindmap_medium",
    "journey_medium",
    "timeline_medium",
    "gantt_medium",
    "requirement_medium",
    "gitgraph_medium",
    "c4_medium",
    "sankey_medium",
    "quadrant_medium",
    "zenuml_medium",
    "block_medium",
    "packet_medium",
    "kanban_medium",
    "architecture_medium",
    "radar_medium",
    "treemap_medium",
    "xychart_medium",
    "flowchart",
    "sequence",
    "class",
    "state",
    "class_tiny",
    "state_tiny",
    "sequence_tiny",
]


def env_bool(name: str) -> bool:
    value = os.environ.get(name)
    if value is None:
        return False
    return value.strip().lower() not in {"", "0", "false", "no", "off"}


MMDR_MEASURE_MEMORY = env_bool("MMDR_MEASURE_MEMORY")
MMD_CLI_MEASURE_MEMORY = env_bool("MMD_CLI_MEASURE_MEMORY")


def benchmark_env() -> dict:
    env = os.environ.copy()
    if "PUPPETEER_EXECUTABLE_PATH" not in env:
        chrome = find_puppeteer_chrome()
        if chrome:
            env["PUPPETEER_EXECUTABLE_PATH"] = chrome
    return env


BENCHMARK_ENV = benchmark_env()


def mmdc_cli_identity(cli_cmd: str) -> str:
    try:
        result = subprocess.run(
            shlex.split(cli_cmd) + ["--version"],
            capture_output=True,
            text=True,
        )
    except OSError as err:
        return f"unavailable: {err}"
    output = (result.stdout or "").strip() or (result.stderr or "").strip()
    if not output:
        output = f"rc={result.returncode}"
    return output.splitlines()[-1][:240]


def mmdc_cache_digest(
    fixture_path: Path,
    cli_cmd: str,
    cli_identity: str,
    runs: int,
    warmup: int,
    config_path: str,
) -> str:
    hasher = hashlib.sha256()
    hasher.update(f"schema:{MMDC_CACHE_SCHEMA_VERSION}\n".encode("utf-8"))
    hasher.update(f"cli:{cli_cmd}\n".encode("utf-8"))
    hasher.update(f"cli_identity:{cli_identity}\n".encode("utf-8"))
    hasher.update(f"runs:{runs}\n".encode("utf-8"))
    hasher.update(f"warmup:{warmup}\n".encode("utf-8"))
    hasher.update(f"config:{config_path}\n".encode("utf-8"))
    hasher.update(fixture_path.read_bytes())
    if config_path:
        cfg = Path(config_path)
        if cfg.exists():
            hasher.update(cfg.read_bytes())
    return hasher.hexdigest()


def load_json_if_exists(path: Path) -> Optional[dict]:
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return data if isinstance(data, dict) else None


def save_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, separators=(",", ":"), sort_keys=True),
        encoding="utf-8",
    )


def init_mmdc_cache_state() -> dict:
    enabled = not env_bool("NO_MMDC_CACHE")
    cache_dir = Path(
        os.environ.get(
            "MMDC_CACHE_DIR",
            str(ROOT / "tmp" / "benchmark-cache" / "bench-compare" / "mmdc"),
        )
    )
    if not enabled:
        return {
            "enabled": False,
            "dir": cache_dir,
            "cli_identity": "",
            "hits": 0,
            "misses": 0,
        }
    cache_dir.mkdir(parents=True, exist_ok=True)
    return {
        "enabled": True,
        "dir": cache_dir,
        "cli_identity": mmdc_cli_identity(MMD_CLI),
        "hits": 0,
        "misses": 0,
    }


def resolve_cases():
    cases_env = os.environ.get("CASES")
    if cases_env:
        requested = [c.strip() for c in cases_env.split(",") if c.strip()]
        unknown = [c for c in requested if c not in CASE_NAMES]
        if unknown:
            raise ValueError(f"Unknown cases: {', '.join(unknown)}")
        names = requested
    else:
        names = CASE_NAMES
    return [(name, FIXTURES / f"{name}.mmd") for name in names]


CASES = resolve_cases()


def iso_utc_now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def git_metadata() -> dict:
    def git(args: list[str]) -> str:
        result = subprocess.run(
            ["git"] + args,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            return ""
        return result.stdout.strip()

    commit = git(["rev-parse", "HEAD"])
    short = commit[:12] if commit else ""
    branch = git(["rev-parse", "--abbrev-ref", "HEAD"])
    describe = git(["describe", "--always", "--dirty", "--tags"])
    status = git(["status", "--porcelain"])
    return {
        "commit": commit,
        "commit_short": short,
        "branch": branch,
        "describe": describe,
        "dirty": bool(status),
    }


def host_metadata() -> dict:
    return {
        "hostname": socket.gethostname(),
        "user": getpass.getuser(),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
    }


def append_benchmark_history(path: Path, record: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True))
        handle.write("\n")


def summarize_history(results: dict) -> dict:
    mmdr_entries = results.get("mmdr", {})
    cli_entries = results.get("mermaid_cli", {})
    compared = []
    cli_errors = 0
    for case, mmdr in mmdr_entries.items():
        mmdr_ms = mmdr.get("mean_ms")
        cli = cli_entries.get(case, {})
        if cli.get("error"):
            cli_errors += 1
            continue
        cli_ms = cli.get("mean_ms")
        if mmdr_ms and cli_ms:
            compared.append((case, float(mmdr_ms), float(cli_ms), float(cli_ms) / float(mmdr_ms)))

    speedups = [item[3] for item in compared]
    best = max(compared, key=lambda item: item[3], default=None)
    worst = min(compared, key=lambda item: item[3], default=None)

    return {
        "case_count": len(mmdr_entries),
        "compared_case_count": len(compared),
        "cli_error_count": cli_errors,
        "mmdr_mean_ms_avg": statistics.mean([entry["mean_ms"] for entry in mmdr_entries.values()]) if mmdr_entries else 0.0,
        "cli_mean_ms_avg": statistics.mean([item[2] for item in compared]) if compared else 0.0,
        "speedup_mean": statistics.mean(speedups) if speedups else 0.0,
        "speedup_median": statistics.median(speedups) if speedups else 0.0,
        "speedup_best_case": best[0] if best else "",
        "speedup_best_value": best[3] if best else 0.0,
        "speedup_worst_case": worst[0] if worst else "",
        "speedup_worst_value": worst[3] if worst else 0.0,
    }


def run_cmd(cmd, capture_stderr=False):
    """Run a command and return (success, stderr_output)."""
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        env=BENCHMARK_ENV,
    )
    if result.returncode != 0 and not capture_stderr:
        raise subprocess.CalledProcessError(result.returncode, cmd)
    return result.returncode == 0, result.stderr


def short_error(text: str, limit: int = 180) -> str:
    cleaned = " ".join(text.split())
    if len(cleaned) <= limit:
        return cleaned
    return cleaned[: limit - 3] + "..."


def get_memory_usage(cmd) -> Optional[int]:
    """Get peak memory usage in KB using /usr/bin/time -v or resource module."""
    # Try GNU time first
    time_bin = "/usr/bin/time"
    if not os.path.exists(time_bin):
        # Try to find it elsewhere
        for path in ["/bin/time", "/usr/local/bin/time"]:
            if os.path.exists(path):
                time_bin = path
                break
        else:
            # Fall back to resource module for rough estimate
            try:
                import resource
                subprocess.run(cmd, capture_output=True, env=BENCHMARK_ENV)
                # This only gets the current process, not subprocess, so it's not accurate
                # Return None to indicate we can't measure
                return None
            except ImportError:
                return None

    time_cmd = [time_bin, "-v"] + cmd
    try:
        result = subprocess.run(time_cmd, capture_output=True, text=True, env=BENCHMARK_ENV)
    except FileNotFoundError:
        return None
    if result.returncode != 0:
        return None
    # Parse "Maximum resident set size (kbytes): 12345"
    for line in result.stderr.split("\n"):
        if "Maximum resident set size" in line:
            match = re.search(r"(\d+)", line)
            if match:
                return int(match.group(1))
    return None


def bench_mmdr(path: Path):
    """Benchmark mmdr with timing breakdown."""
    out = ROOT / "target" / f"bench-{path.stem}.svg"
    extra_args = shlex.split(os.environ.get("MMDR_ARGS", ""))
    cmd_base = [BIN, "-i", str(path), "-o", str(out), "-e", "svg"] + extra_args
    cmd = cmd_base + ["--timing"]

    times = []
    breakdowns = []

    # Warmup
    for _ in range(WARMUP):
        run_cmd(cmd, capture_stderr=True)

    # Actual runs
    for _ in range(RUNS):
        start = time.perf_counter()
        success, stderr = run_cmd(cmd, capture_stderr=True)
        elapsed = time.perf_counter() - start
        times.append(elapsed)

        if success and stderr.strip():
            try:
                timing = json.loads(stderr.strip())
                breakdowns.append(timing)
            except json.JSONDecodeError:
                pass

    # Optional: mmdr memory probing executes one extra process per case.
    memory_kb = get_memory_usage(cmd_base) if MMDR_MEASURE_MEMORY else None

    return {
        "times": times,
        "breakdowns": breakdowns,
        "memory_kb": memory_kb,
    }


def bench_mermaid_cli(path: Path, cache_state: dict):
    """Benchmark mermaid-cli (no timing breakdown available)."""
    out = ROOT / "target" / f"bench-{path.stem}-mmdc.svg"
    cmd = shlex.split(MMD_CLI) + ["-i", str(path), "-o", str(out)]
    if MMDC_CONFIG:
        cfg = Path(MMDC_CONFIG)
        if cfg.exists():
            cmd += ["-c", str(cfg)]

    cache_json_path: Optional[Path] = None
    cache_svg_path: Optional[Path] = None
    if cache_state.get("enabled"):
        digest = mmdc_cache_digest(
            path,
            MMD_CLI,
            cache_state.get("cli_identity", ""),
            MMD_CLI_RUNS,
            MMD_CLI_WARMUP,
            MMDC_CONFIG,
        )
        cache_json_path = Path(cache_state["dir"]) / f"{digest}.json"
        cache_svg_path = Path(cache_state["dir"]) / f"{digest}.svg"
        cached = load_json_if_exists(cache_json_path)
        if cached is not None:
            if cache_svg_path.exists():
                shutil.copy2(cache_svg_path, out)
            cached_result = dict(cached)
            cached_result["cached"] = True
            cached_result["cache_hit"] = 1
            cached_result["cache_miss"] = 0
            return cached_result

    times = []

    # Warmup (if any). When warmup is 0, do not run an extra preflight because that
    # doubles cold-run mermaid-cli time.
    for _ in range(MMD_CLI_WARMUP):
        success, stderr = run_cmd(cmd, capture_stderr=True)
        if not success:
            result = {
                "times": [],
                "memory_kb": None,
                "error": short_error(stderr) or "mmdc failed",
                "cache_hit": 0,
                "cache_miss": 1 if cache_json_path else 0,
            }
            if cache_json_path:
                save_json(cache_json_path, result)
            return result

    # Actual runs
    measured_runs = MMD_CLI_RUNS if MMD_CLI_RUNS > 0 else 1
    for _ in range(measured_runs):
        start = time.perf_counter()
        success, stderr = run_cmd(cmd, capture_stderr=True)
        elapsed = time.perf_counter() - start
        if not success:
            result = {
                "times": [],
                "memory_kb": None,
                "error": short_error(stderr) or "mmdc failed",
                "cache_hit": 0,
                "cache_miss": 1 if cache_json_path else 0,
            }
            if cache_json_path:
                save_json(cache_json_path, result)
            return result
        times.append(elapsed)

    # Optional: mermaid-cli memory probing is expensive because it executes
    # the command again under `/usr/bin/time`.
    memory_kb = get_memory_usage(cmd) if MMD_CLI_MEASURE_MEMORY else None
    result = {
        "times": times,
        "memory_kb": memory_kb,
        "cache_hit": 0,
        "cache_miss": 1 if cache_json_path else 0,
    }
    if cache_json_path:
        save_json(cache_json_path, result)
        if cache_svg_path and out.exists():
            cache_svg_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(out, cache_svg_path)

    return result


def summarize(times):
    """Summarize timing statistics."""
    return {
        "mean_ms": statistics.mean(times) * 1000,
        "median_ms": statistics.median(times) * 1000,
        "min_ms": min(times) * 1000,
        "max_ms": max(times) * 1000,
    }


def summarize_breakdowns(breakdowns):
    """Summarize pipeline breakdown statistics."""
    if not breakdowns:
        return None
    parse_us = [b["parse_us"] for b in breakdowns]
    layout_us = [b["layout_us"] for b in breakdowns]
    render_us = [b["render_us"] for b in breakdowns]
    return {
        "parse_ms": statistics.mean(parse_us) / 1000,
        "layout_ms": statistics.mean(layout_us) / 1000,
        "render_ms": statistics.mean(render_us) / 1000,
    }


def generate_svg_chart(results: dict, output_path: Path):
    """Generate an SVG bar chart comparing mmdr vs mermaid-cli."""
    # Chart dimensions
    width = 800
    height = 400
    margin = {"top": 40, "right": 150, "bottom": 80, "left": 120}
    chart_width = width - margin["left"] - margin["right"]
    chart_height = height - margin["top"] - margin["bottom"]

    # Prepare data
    cases = list(results["mmdr"].keys())
    mmdr_times = [results["mmdr"][c]["mean_ms"] for c in cases]
    cli_times = []
    for c in cases:
        entry = results.get("mermaid_cli", {}).get(c)
        if entry and entry.get("mean_ms") is not None:
            cli_times.append(entry["mean_ms"])

    # Use log scale for y-axis since values differ by 1000x
    import math

    max_time = max(mmdr_times + cli_times) if cli_times else max(mmdr_times)
    min_time = min(mmdr_times)

    # Create SVG
    svg_lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}">',
        f'<rect width="{width}" height="{height}" fill="#FFFFFF"/>',
        '<style>',
        '  .title { font: bold 16px sans-serif; }',
        '  .axis-label { font: 12px sans-serif; }',
        '  .tick-label { font: 11px sans-serif; }',
        '  .legend { font: 12px sans-serif; }',
        '  .bar-mmdr { fill: #2e7d32; }',
        '  .bar-cli { fill: #f57c00; }',
        '  .bar-label { font: 10px sans-serif; fill: white; }',
        '</style>',
        f'<text x="{width/2}" y="25" text-anchor="middle" class="title">Render Time Comparison (log scale)</text>',
    ]

    # Y-axis (log scale)
    y_ticks = [1, 10, 100, 1000, 10000]
    for tick in y_ticks:
        if tick > max_time * 1.5:
            continue
        y = margin["top"] + chart_height - (math.log10(tick) / math.log10(max_time * 1.5)) * chart_height
        svg_lines.append(
            f'<line x1="{margin["left"]}" y1="{y}" x2="{margin["left"] + chart_width}" y2="{y}" stroke="#ddd" stroke-dasharray="2,2"/>'
        )
        svg_lines.append(
            f'<text x="{margin["left"] - 10}" y="{y + 4}" text-anchor="end" class="tick-label">{tick} ms</text>'
        )

    # Bars
    bar_width = chart_width / len(cases) * 0.35
    bar_gap = chart_width / len(cases)

    for i, case in enumerate(cases):
        x_base = margin["left"] + i * bar_gap + bar_gap * 0.15

        # mmdr bar
        mmdr_time = results["mmdr"][case]["mean_ms"]
        mmdr_height = (math.log10(max(mmdr_time, 0.1)) / math.log10(max_time * 1.5)) * chart_height
        mmdr_y = margin["top"] + chart_height - mmdr_height
        svg_lines.append(
            f'<rect x="{x_base}" y="{mmdr_y}" width="{bar_width}" height="{mmdr_height}" class="bar-mmdr" rx="2"/>'
        )
        svg_lines.append(
            f'<text x="{x_base + bar_width/2}" y="{mmdr_y + 15}" text-anchor="middle" class="bar-label">{mmdr_time:.1f}</text>'
        )

        # mermaid-cli bar
        cli_entry = results.get("mermaid_cli", {}).get(case)
        if cli_entry and cli_entry.get("mean_ms") is not None:
            cli_time = cli_entry["mean_ms"]
            cli_height = (math.log10(max(cli_time, 0.1)) / math.log10(max_time * 1.5)) * chart_height
            cli_y = margin["top"] + chart_height - cli_height
            svg_lines.append(
                f'<rect x="{x_base + bar_width + 5}" y="{cli_y}" width="{bar_width}" height="{cli_height}" class="bar-cli" rx="2"/>'
            )
            svg_lines.append(
                f'<text x="{x_base + bar_width + 5 + bar_width/2}" y="{cli_y + 15}" text-anchor="middle" class="bar-label">{cli_time:.0f}</text>'
            )

        # X-axis label
        label = case.replace("_", " ").replace("flowchart ", "flow ").replace("medium", "med")
        svg_lines.append(
            f'<text x="{x_base + bar_width}" y="{margin["top"] + chart_height + 20}" text-anchor="middle" class="tick-label" transform="rotate(-30 {x_base + bar_width} {margin["top"] + chart_height + 20})">{label}</text>'
        )

    # Legend
    legend_x = margin["left"] + chart_width + 20
    legend_y = margin["top"] + 20
    svg_lines.append(f'<rect x="{legend_x}" y="{legend_y}" width="15" height="15" class="bar-mmdr"/>')
    svg_lines.append(f'<text x="{legend_x + 20}" y="{legend_y + 12}" class="legend">mmdr</text>')
    if cli_times:
        svg_lines.append(f'<rect x="{legend_x}" y="{legend_y + 25}" width="15" height="15" class="bar-cli"/>')
        svg_lines.append(f'<text x="{legend_x + 20}" y="{legend_y + 37}" class="legend">mermaid-cli</text>')

    # Axes
    svg_lines.append(
        f'<line x1="{margin["left"]}" y1="{margin["top"]}" x2="{margin["left"]}" y2="{margin["top"] + chart_height}" stroke="#333" stroke-width="2"/>'
    )
    svg_lines.append(
        f'<line x1="{margin["left"]}" y1="{margin["top"] + chart_height}" x2="{margin["left"] + chart_width}" y2="{margin["top"] + chart_height}" stroke="#333" stroke-width="2"/>'
    )

    svg_lines.append("</svg>")

    output_path.write_text("\n".join(svg_lines))
    print(f"Wrote chart: {output_path}")


def generate_breakdown_chart(results: dict, output_path: Path):
    """Generate an SVG showing pipeline breakdown for mmdr."""
    width = 600
    height = 300
    margin = {"top": 40, "right": 30, "bottom": 80, "left": 100}
    chart_width = width - margin["left"] - margin["right"]
    chart_height = height - margin["top"] - margin["bottom"]

    cases = [c for c in results["mmdr"].keys() if results["mmdr"][c].get("breakdown")]
    if not cases:
        print("No breakdown data available")
        return

    svg_lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}">',
        f'<rect width="{width}" height="{height}" fill="#FFFFFF"/>',
        '<style>',
        '  .title { font: bold 14px sans-serif; }',
        '  .tick-label { font: 10px sans-serif; }',
        '  .legend { font: 11px sans-serif; }',
        '  .bar-parse { fill: #4CAF50; }',
        '  .bar-layout { fill: #2196F3; }',
        '  .bar-render { fill: #FF9800; }',
        '</style>',
        f'<text x="{width/2}" y="25" text-anchor="middle" class="title">mmdr Pipeline Breakdown</text>',
    ]

    # Calculate max time for scale
    max_time = 0
    for case in cases:
        bd = results["mmdr"][case]["breakdown"]
        total = bd["parse_ms"] + bd["layout_ms"] + bd["render_ms"]
        max_time = max(max_time, total)

    bar_height = chart_height / len(cases) * 0.7
    bar_gap = chart_height / len(cases)

    for i, case in enumerate(cases):
        y_base = margin["top"] + i * bar_gap + bar_gap * 0.15
        bd = results["mmdr"][case]["breakdown"]

        # Stacked bars
        x = margin["left"]
        for stage, cls in [("parse_ms", "bar-parse"), ("layout_ms", "bar-layout"), ("render_ms", "bar-render")]:
            w = (bd[stage] / max_time) * chart_width
            svg_lines.append(f'<rect x="{x}" y="{y_base}" width="{w}" height="{bar_height}" class="{cls}"/>')
            if w > 25:
                svg_lines.append(
                    f'<text x="{x + w/2}" y="{y_base + bar_height/2 + 4}" text-anchor="middle" fill="white" font-size="9">{bd[stage]:.2f}</text>'
                )
            x += w

        # Case label
        label = case.replace("_", " ")
        svg_lines.append(
            f'<text x="{margin["left"] - 5}" y="{y_base + bar_height/2 + 4}" text-anchor="end" class="tick-label">{label}</text>'
        )

    # Legend
    legend_y = height - 30
    svg_lines.append(f'<rect x="{margin["left"]}" y="{legend_y}" width="12" height="12" class="bar-parse"/>')
    svg_lines.append(f'<text x="{margin["left"] + 17}" y="{legend_y + 10}" class="legend">Parse</text>')
    svg_lines.append(f'<rect x="{margin["left"] + 80}" y="{legend_y}" width="12" height="12" class="bar-layout"/>')
    svg_lines.append(f'<text x="{margin["left"] + 97}" y="{legend_y + 10}" class="legend">Layout</text>')
    svg_lines.append(f'<rect x="{margin["left"] + 170}" y="{legend_y}" width="12" height="12" class="bar-render"/>')
    svg_lines.append(f'<text x="{margin["left"] + 187}" y="{legend_y + 10}" class="legend">Render</text>')

    svg_lines.append("</svg>")
    output_path.write_text("\n".join(svg_lines))
    print(f"Wrote breakdown chart: {output_path}")


def parse_args() -> None:
    parser = argparse.ArgumentParser(
        description="Benchmark mmdr against mermaid-cli",
        epilog=(
            "Configuration is supplied through environment variables. Common settings: "
            "MMDR_BIN, MMD_CLI, RUNS, WARMUP, CASES, SKIP_MERMAID_CLI, "
            "SKIP_CHARTS, OUT_JSON, and NO_HISTORY_LOG. See docs/benchmarks.md."
        ),
    )
    parser.parse_args()


def main():
    parse_args()
    results = {"mmdr": {}, "mermaid_cli": {}}
    mmdc_cache_state = init_mmdc_cache_state()
    runtime = {}
    run_start = time.perf_counter()

    print("Benchmarking mmdr...")
    print(
        "  sampling config: "
        f"runs={RUNS}, warmup={WARMUP}, jobs={MMDR_JOBS}, "
        f"measure_memory={str(MMDR_MEASURE_MEMORY).lower()}"
    )
    phase_start = time.perf_counter()
    mmdr_data_by_case = {}
    if MMDR_JOBS <= 1:
        for name, path in CASES:
            print(f"  {name}...", end=" ", flush=True)
            data = bench_mmdr(path)
            mmdr_data_by_case[name] = data
            summary = summarize(data["times"])
            breakdown = summarize_breakdowns(data["breakdowns"])
            if breakdown:
                print(
                    f"total={summary['mean_ms']:.2f}ms "
                    f"(parse={breakdown['parse_ms']:.2f} "
                    f"layout={breakdown['layout_ms']:.2f} "
                    f"render={breakdown['render_ms']:.2f})"
                )
            else:
                print(f"total={summary['mean_ms']:.2f}ms")
    else:
        with concurrent.futures.ThreadPoolExecutor(max_workers=MMDR_JOBS) as pool:
            future_to_name = {
                pool.submit(bench_mmdr, path): name
                for name, path in CASES
            }
            completed = 0
            total = len(CASES)
            for future in concurrent.futures.as_completed(future_to_name):
                name = future_to_name[future]
                data = future.result()
                mmdr_data_by_case[name] = data
                completed += 1
                summary = summarize(data["times"])
                breakdown = summarize_breakdowns(data["breakdowns"])
                if breakdown:
                    print(
                        f"  [{completed:>2}/{total}] {name}... "
                        f"total={summary['mean_ms']:.2f}ms "
                        f"(parse={breakdown['parse_ms']:.2f} "
                        f"layout={breakdown['layout_ms']:.2f} "
                        f"render={breakdown['render_ms']:.2f})"
                    )
                else:
                    print(
                        f"  [{completed:>2}/{total}] {name}... "
                        f"total={summary['mean_ms']:.2f}ms"
                    )
    for name, _ in CASES:
        data = mmdr_data_by_case[name]
        results["mmdr"][name] = {
            **summarize(data["times"]),
            "breakdown": summarize_breakdowns(data["breakdowns"]),
            "memory_kb": data["memory_kb"],
        }
    runtime["mmdr_s"] = time.perf_counter() - phase_start

    if os.environ.get("SKIP_MERMAID_CLI"):
        print("SKIP_MERMAID_CLI set, skipping mermaid-cli")
        runtime["mermaid_cli_s"] = 0.0
    else:
        print("\nBenchmarking mermaid-cli...")
        print(
            "  sampling config: "
            f"runs={MMD_CLI_RUNS}, warmup={MMD_CLI_WARMUP}, "
            f"jobs={MMD_CLI_JOBS}, measure_memory={str(MMD_CLI_MEASURE_MEMORY).lower()}"
        )
        phase_start = time.perf_counter()
        cli_data_by_case = {}
        if MMD_CLI_JOBS <= 1:
            for name, path in CASES:
                print(f"  {name}...", end=" ", flush=True)
                data = bench_mermaid_cli(path, mmdc_cache_state)
                cli_data_by_case[name] = data
                if data.get("error"):
                    print(f"error={data['error']}")
                else:
                    cached_suffix = " (cached)" if data.get("cached") else ""
                    print(
                        f"total={summarize(data['times'])['mean_ms']:.2f}ms{cached_suffix}"
                    )
        else:
            with concurrent.futures.ThreadPoolExecutor(max_workers=MMD_CLI_JOBS) as pool:
                future_to_name = {
                    pool.submit(bench_mermaid_cli, path, mmdc_cache_state): name
                    for name, path in CASES
                }
                completed = 0
                total = len(CASES)
                for future in concurrent.futures.as_completed(future_to_name):
                    name = future_to_name[future]
                    data = future.result()
                    cli_data_by_case[name] = data
                    completed += 1
                    if data.get("error"):
                        print(f"  [{completed:>2}/{total}] {name}... error={data['error']}")
                    else:
                        cached_suffix = " (cached)" if data.get("cached") else ""
                        print(
                            f"  [{completed:>2}/{total}] {name}... "
                            f"total={summarize(data['times'])['mean_ms']:.2f}ms{cached_suffix}"
                        )

        cache_hits = 0
        cache_misses = 0
        for name, _ in CASES:
            data = cli_data_by_case.get(name, {})
            cache_hits += int(data.get("cache_hit", 0))
            cache_misses += int(data.get("cache_miss", 0))
            if data.get("error"):
                results["mermaid_cli"][name] = {
                    "error": data["error"],
                    "memory_kb": data.get("memory_kb"),
                }
            else:
                results["mermaid_cli"][name] = {
                    **summarize(data["times"]),
                    "memory_kb": data.get("memory_kb"),
                }
        mmdc_cache_state["hits"] = cache_hits
        mmdc_cache_state["misses"] = cache_misses
        runtime["mermaid_cli_s"] = time.perf_counter() - phase_start

    # Print summary
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)

    print("\nTiming (mean ms):")
    print(f"{'Case':<20} {'mmdr':>10} {'mermaid-cli':>12} {'Speedup':>10}")
    print("-" * 55)
    for name in results["mmdr"].keys():
        mmdr_ms = results["mmdr"][name]["mean_ms"]
        cli_entry = results.get("mermaid_cli", {}).get(name)
        if cli_entry and cli_entry.get("error"):
            print(f"{name:<20} {mmdr_ms:>10.2f} {'ERR':>12}")
        elif cli_entry and cli_entry.get("mean_ms") is not None:
            cli_ms = cli_entry["mean_ms"]
            speedup = cli_ms / mmdr_ms
            print(f"{name:<20} {mmdr_ms:>10.2f} {cli_ms:>12.0f} {speedup:>9.0f}x")
        else:
            print(f"{name:<20} {mmdr_ms:>10.2f} {'N/A':>12}")

    print("\nPipeline Breakdown (mmdr, mean ms):")
    print(f"{'Case':<20} {'Parse':>8} {'Layout':>8} {'Render':>8} {'Total':>8}")
    print("-" * 55)
    for name in results["mmdr"].keys():
        bd = results["mmdr"][name].get("breakdown")
        if bd:
            total = bd["parse_ms"] + bd["layout_ms"] + bd["render_ms"]
            print(f"{name:<20} {bd['parse_ms']:>8.2f} {bd['layout_ms']:>8.2f} {bd['render_ms']:>8.2f} {total:>8.2f}")

    print("\nMemory Usage (peak RSS):")
    print(f"{'Case':<20} {'mmdr':>12} {'mermaid-cli':>12}")
    print("-" * 45)
    for name in results["mmdr"].keys():
        mmdr_mem = results["mmdr"][name].get("memory_kb")
        mmdr_str = f"{mmdr_mem / 1024:.1f} MB" if mmdr_mem else "N/A"
        cli_entry = results.get("mermaid_cli", {}).get(name)
        if cli_entry and cli_entry.get("error"):
            cli_str = "ERR"
        elif cli_entry:
            cli_mem = cli_entry.get("memory_kb")
            cli_str = f"{cli_mem / 1024:.1f} MB" if cli_mem else "N/A"
        else:
            cli_str = "N/A"
        print(f"{name:<20} {mmdr_str:>12} {cli_str:>12}")

    # Write JSON
    out_json = Path(os.environ.get("OUT_JSON", str(ROOT / "target" / "bench-results.json")))
    out_json.write_text(json.dumps(results, indent=2))
    print(f"\nWrote {out_json}")

    # Generate charts unless explicitly skipped
    phase_start = time.perf_counter()
    if not os.environ.get("SKIP_CHARTS"):
        charts_dir = Path(os.environ.get("CHARTS_DIR", str(ROOT / "docs" / "benchmarks")))
        charts_dir.mkdir(parents=True, exist_ok=True)
        generate_svg_chart(results, charts_dir / "comparison_chart.svg")
        generate_breakdown_chart(results, charts_dir / "breakdown_chart.svg")
    runtime["charts_s"] = time.perf_counter() - phase_start

    if mmdc_cache_state.get("enabled"):
        print(
            "mermaid-cli cache: "
            f"hits={mmdc_cache_state.get('hits', 0)} "
            f"misses={mmdc_cache_state.get('misses', 0)} "
            f"dir={mmdc_cache_state.get('dir')}"
        )

    runtime["history_s"] = 0.0
    runtime["total_pre_history_s"] = time.perf_counter() - run_start
    if not env_bool("NO_HISTORY_LOG"):
        phase_start = time.perf_counter()
        record = {
            "timestamp_utc": iso_utc_now(),
            "history_version": 1,
            "tool": "bench_compare",
            "cwd": str(ROOT),
            "argv": sys.argv[1:],
            "git": git_metadata(),
            "host": host_metadata(),
            "settings": {
                "bin": BIN,
                "mmd_cli": MMD_CLI,
                "runs": RUNS,
                "warmup": WARMUP,
                "mmdr_jobs": MMDR_JOBS,
                "mmdr_measure_memory": MMDR_MEASURE_MEMORY,
                "mmd_cli_runs": MMD_CLI_RUNS,
                "mmd_cli_warmup": MMD_CLI_WARMUP,
                "mmd_cli_jobs": MMD_CLI_JOBS,
                "mmd_cli_measure_memory": MMD_CLI_MEASURE_MEMORY,
                "mmdc_config": MMDC_CONFIG,
                "cases": [name for name, _ in CASES],
                "skip_mermaid_cli": bool(os.environ.get("SKIP_MERMAID_CLI")),
                "skip_charts": bool(os.environ.get("SKIP_CHARTS")),
                "mmdc_cache_enabled": bool(mmdc_cache_state.get("enabled")),
                "mmdc_cache_dir": str(mmdc_cache_state.get("dir")),
                "mmdc_cache_hits": int(mmdc_cache_state.get("hits", 0)),
                "mmdc_cache_misses": int(mmdc_cache_state.get("misses", 0)),
                "out_json": str(out_json),
                "charts_dir": str(Path(os.environ.get("CHARTS_DIR", str(ROOT / "docs" / "benchmarks")))),
            },
            "runtime": dict(runtime),
            "summary": summarize_history(results),
        }
        append_benchmark_history(HISTORY_LOG, record)
        runtime["history_s"] = time.perf_counter() - phase_start
        print(f"Wrote history: {HISTORY_LOG}")
    runtime["total_s"] = time.perf_counter() - run_start
    print(
        "runtime breakdown (s): "
        f"mmdr={runtime.get('mmdr_s', 0.0):.2f}, "
        f"mermaid-cli={runtime.get('mermaid_cli_s', 0.0):.2f}, "
        f"charts={runtime.get('charts_s', 0.0):.2f}, "
        f"history={runtime.get('history_s', 0.0):.2f}, "
        f"total={runtime.get('total_s', 0.0):.2f}"
    )


if __name__ == "__main__":
    main()
