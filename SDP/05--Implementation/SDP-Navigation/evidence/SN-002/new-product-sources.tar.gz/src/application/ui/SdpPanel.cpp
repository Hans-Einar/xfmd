#include "SdpPanel.h"
#include <algorithm>
#include <set>
using namespace FX;
namespace xfmd {
namespace {
class SdpStatus : public FXLabel {
public:
  explicit SdpStatus(FXComposite* parent)
      : FXLabel(parent, "", nullptr, LAYOUT_FILL_X | JUSTIFY_LEFT) {}
  FXint getDefaultWidth() override { return 10; }
};
struct SdpItem : NavigationItem {
  std::string id;
  std::vector<std::string> ancestors;
  bool populated = false;
  SdpItem(const std::string& label, std::string id, std::vector<std::string> ancestors,
          IndexAction action)
      : NavigationItem(label, std::move(action)), id(std::move(id)),
        ancestors(std::move(ancestors)) {}
};
} // namespace
SdpPanel::SdpPanel(FXComposite* parent)
    : FXVerticalFrame(parent, LAYOUT_FILL_X | LAYOUT_FILL_Y, 0, 0, 0, 0, 0, 0, 0, 0) {
  status = new SdpStatus(this);
  tabs = new FXTabBook(this, nullptr, 0, LAYOUT_FILL_X | LAYOUT_FILL_Y);
  const char* names[]{"KanBan", "SDL", "SDUI"};
  for (std::size_t i = 0; i < trees.size(); ++i) {
    new FXTabItem(tabs, names[i]);
    auto* page = new FXVerticalFrame(tabs, LAYOUT_FILL_X | LAYOUT_FILL_Y, 0, 0, 0, 0, 0, 0, 0, 0);
    auto* tree = trees[i] = new NavigationTree(page);
    tree->expanded = [this, tree](NavigationItem* item) { expand(tree, item); };
    tree->activated = [this](const IndexAction& action) {
      auto found = snapshot.nodes.find(action.target);
      if (found != snapshot.nodes.end() && activated)
        activated(found->second.target);
    };
  }
}
void SdpPanel::message(const std::string& text) {
  status->setText(text.substr(0, 100).c_str());
  status->setTipText(text.c_str());
}
void SdpPanel::clear() {
  for (auto* tree : trees) {
    tree->cancelActivation();
    tree->clearItems();
  }
  snapshot = {};
  rows = 0;
}
void SdpPanel::present(SdpReply value) {
  std::array<std::set<std::string>, 3> expanded;
  std::array<std::string, 3> selected;
  for (std::size_t i = 0; i < trees.size(); ++i) {
    if (auto* item = dynamic_cast<SdpItem*>(trees[i]->getCurrentItem()))
      selected[i] = item->id;
    std::function<void(FXTreeItem*)> remember = [&](FXTreeItem* first) {
      for (auto* row = first; row; row = row->getNext()) {
        if (auto* item = dynamic_cast<SdpItem*>(row); item && item->isExpanded())
          expanded[i].insert(item->id);
        remember(row->getFirst());
      }
    };
    remember(trees[i]->getFirstItem());
  }
  clear();
  snapshot = std::move(value);
  const char* roots[]{"kanban", "sdl", "sdui"};
  for (std::size_t i = 0; i < trees.size(); ++i) {
    const auto& root = snapshot.nodes.at(roots[i]);
    for (const auto& child : root.children) {
      if (rows >= 4096) {
        trees[i]->appendItem(nullptr,
                             new NavigationItem("Display limit — narrow the source model"));
        break;
      }
      add(trees[i], nullptr, child, {roots[i]});
    }
    if (!root.diagnostic.empty())
      trees[i]->appendItem(nullptr, new NavigationItem(root.diagnostic));
    if (root.children.empty())
      trees[i]->appendItem(nullptr, new NavigationItem("No entries — " + root.state));
    // Find one short route to the previous selection, including moved cards.
    std::map<std::string, std::string> parent;
    std::vector<std::string> queue{roots[i]};
    parent.emplace(roots[i], "");
    for (std::size_t q = 0; q < queue.size() && !parent.count(selected[i]); ++q) {
      const auto& node = snapshot.nodes.at(queue[q]);
      auto children = node.children;
      if (!node.reference.empty())
        children.push_back(node.reference);
      for (const auto& child : children)
        if (parent.emplace(child, node.id).second)
          queue.push_back(child);
    }
    if (parent.count(selected[i]))
      for (auto id = parent.at(selected[i]); !id.empty(); id = parent.at(id))
        expanded[i].insert(id);
    bool restored = false;
    std::function<void(FXTreeItem*)> restore = [&](FXTreeItem* first) {
      for (auto* row = first; row; row = row->getNext()) {
        if (auto* item = dynamic_cast<SdpItem*>(row)) {
          if (expanded[i].count(item->id))
            trees[i]->expandTree(item);
          if (!restored && item->id == selected[i]) {
            trees[i]->setCurrentItem(item);
            trees[i]->selectItem(item);
            restored = true;
          }
        }
        restore(row->getFirst());
      }
    };
    restore(trees[i]->getFirstItem());
    if (restored)
      trees[i]->makeItemVisible(trees[i]->getCurrentItem());
  }
  message(snapshot.project + " — Navigation updated; views are snapshots");
}
void SdpPanel::add(NavigationTree* tree, NavigationItem* parent, const std::string& id,
                   std::vector<std::string> ancestors) {
  if (rows >= 4096)
    return;
  ++rows;
  auto found = snapshot.nodes.find(id);
  if (found == snapshot.nodes.end())
    return;
  auto label = found->second.label;
  auto node = &found->second;
  bool bounded = false;
  for (;;) {
    if (ancestors.size() >= 32 ||
        std::find(ancestors.begin(), ancestors.end(), node->id) != ancestors.end()) {
      bounded = true;
      label += " [reference/depth limit]";
      break;
    }
    ancestors.push_back(node->id);
    if (node->reference.empty())
      break;
    if (node->target.operation == "open") {
      label += " [Ref: " + node->reference + "]";
      break; // A card keeps its own typed open target, even when it refers to another card.
    }
    label += " [reference]";
    node = &snapshot.nodes.at(node->reference);
  }
  if (node->state == "invalid" || node->state == "context-required" || node->state == "unsupported")
    label += " [" + node->state + "]";
  if (!node->cardType.empty())
    label += " [Ref: " + node->cardType + "]";
  IndexAction action;
  const auto& op = node->target.operation;
  if (!bounded &&
      (op == "open" || op == "select" || (op == "sdui-preview" && !node->target.entry.empty()))) {
    action.kind = IndexActionKind::Command;
    action.target = node->id;
  }
  auto* item = new SdpItem(label, node->id, std::move(ancestors), std::move(action));
  tree->appendItem(parent, item);
  item->populated = bounded;
  item->setHasItems(!bounded && (!node->children.empty() || !node->diagnostic.empty()));
}
void SdpPanel::expand(NavigationTree* tree, NavigationItem* value) {
  auto* item = dynamic_cast<SdpItem*>(value);
  if (!item || item->populated)
    return;
  item->populated = true;
  const auto& node = snapshot.nodes.at(item->id);
  if (!node.diagnostic.empty())
    tree->appendItem(item, new NavigationItem(node.diagnostic));
  for (const auto& child : node.children) {
    if (rows >= 4096) {
      tree->appendItem(item, new NavigationItem("Display limit — Refresh to reset"));
      break;
    }
    add(tree, item, child, item->ancestors);
  }
}
} // namespace xfmd
