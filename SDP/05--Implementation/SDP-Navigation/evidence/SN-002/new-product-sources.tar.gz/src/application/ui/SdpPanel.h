#pragma once
#include "NavigationTree.h"
#include "application/sdp/SdpProtocol.h"
#include <array>
namespace xfmd {
class SdpPanel : public FX::FXVerticalFrame {
  SdpReply snapshot;
  std::size_t rows = 0;
  void add(NavigationTree*, NavigationItem*, const std::string&, std::vector<std::string>);
  void expand(NavigationTree*, NavigationItem*);

public:
  FX::FXTabBook* tabs;
  FX::FXLabel* status;
  std::array<NavigationTree*, 3> trees;
  std::function<void(const SdpTarget&)> activated;
  explicit SdpPanel(FX::FXComposite*);
  void clear();
  void present(SdpReply);
  void message(const std::string&);
};
} // namespace xfmd
