#pragma once
#include "SdpToolJob.h"
#include "SdpWatch.h"
#include "contracts/DocumentTypes.h"
#include <filesystem>
namespace xfmd {
class Application;
class SdpNavigation {
  Application& app;
  SdpToolJob job;
  SdpWatch watch;
  bool refreshQueued = false;
  std::string watchError;
  std::string root, area, project, pendingOperation;
  std::filesystem::path temporary, pendingBundle;
  std::size_t request = 0, retainedBytes = 0;
  DocumentToken token;
  SdpTarget selection;
  struct Context {
    std::string root;
    SdpTarget target;
  };
  std::map<std::string, Context> contexts;
  void poll();
  void pollWatch();
  void discover();
  void cancelRequest();
  void start(const std::string& operation, std::vector<std::string> args);
  void message(const std::string&);
  void discardPending();
  bool deliver(const SdpReply&);

public:
  explicit SdpNavigation(Application&);
  ~SdpNavigation();
  void stop();
  void refresh(const std::string&);
  void activate(const SdpTarget&);
  bool follow(const std::string& document, const std::string& uri);
};
} // namespace xfmd
