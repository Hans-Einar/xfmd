---
id: FUNC-032
kind: Functionality
audience: User
role: Workflow
owner: application
status: Implemented
scope: FirstRelease
requirements: UR-046, SR-029
uses: FUNC-001, FUNC-002, FUNC-005, FUNC-006, FUNC-007, FUNC-008, FUNC-010
---

# Functionality-032: SDP project navigation

## 1. Purpose and scope

UC-012 adds project-aware KanBan/SDL/SDUI browsing and selected generated views.
The owning work is [PLAN-XFMD-0006](../../../SDP/05--Implementation/SDP-Navigation/Plan.md).
Existing FUNC-031 explicit navigator/endpoint behavior remains a separate consumer.

## 2. Requirements and acceptance

UR-046/SR-029; AT-074, AT-075 cover the native workflow and asynchronous failure
boundaries. Native source editing/standalone preview is a later #015 increment.

## 3. Contracts and ownership

Application owns SdpNavigation, SdpToolJob, SdpProtocol and SdpPanel. Tool jobs
run outside FOX; presentation and document admission occur on the owning window's
main thread. SdpProtocol decodes sdptool/0.2 through an application-local Rust
serde_json bridge (already locked/offline dependency), not an SDL parser. The
bridge has a separate crate; it does not add SDP semantics to Mermaid layers.

Discovery returns a bounded graph with typed targets. Use returned model IDs,
URI, revision, frame entry and absolute open paths. Host default argv is gh sdp;
XFMD_SDP_TOOL overrides one executable (standalone sdptool), never a shell string
or a project manifest command. Inherit the host's SDP_OFFLINE/cache policy.

## 4. Behavior, state and failures

Recognize only the current directory named SDP or its immediate real SDP child;
no ancestor search. Discovery establishes actual validity. Candidate errors have
visible SDP diagnostics; a non-SDP root hides the tab. Refresh invalidates old
requests and tree activations. Keep Files and Index independent.

NavigationTree expands graph children lazily with an ancestor/reference guard,
depth and total-row bounds. Unknown operations have no executable effect.
SDUI source rows expand frames; explicit frame selection generates its preview.
Open targets use existing native document opening, not desktop launch. All
producer paths must remain inside the selected SDP area; generation results must
remain inside the private request bundle. Child processes use argv, a process
group, cancellation, a deadline and bounded output. No shell is involved.

Each selection captures the document token. Dirty buffers reject generated
selection/delivery without saving or a late modal. Root changes, refresh and newer
selections cancel the job; a changed document token rejects delivery even if the
source revision matches. Generated sdl-view links retain their originating model
and revision. Bundles survive normal Back/Forward for the window lifetime, with
a finite admission limit. Destroy services/render workers before deleting bundles.

## 5. Plumbing

| Step | Event / caller | Called symbol | Source or contract file | Data / result | Failure / side effect | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Application workspace root/refresh | `SdpNavigation::refresh` | `src/application/sdp/SdpNavigation.cpp` | root → discovery request | cancel prior request; clear old graph | Implemented |
| 2 | SdpNavigation | `SdpToolJob::start` | `src/application/sdp/SdpToolJob.cpp` | argv → bounded background result | process group canceled/reaped | Implemented |
| 3 | SdpToolJob | `decodeSdpReply` | `src/application/sdp/SdpProtocol.cpp` | JSON → application DTO | reject unknown schema/invalid graph | Implemented |
| 4 | SdpNavigation result | `SdpPanel::present` | `src/application/ui/SdpPanel.cpp` | graph → lazy native rows | diagnostics remain visible | Implemented |
| 5 | SdpPanel activation | `SdpNavigation::activate` | `src/application/sdp/SdpNavigation.cpp` | typed target → open/select/frame | containment, revision and dirty checks | Implemented |
| 7 | Background source/card changes | `SdpWatch::take` | `src/application/sdp/SdpWatch.cpp` | coalesced change → rediscovery | bounded scan errors require manual Refresh | Implemented |
| 6 | SdpNavigation poll | `Application::open` | `src/application/Application.cpp` | admitted bundle entry → main document | changed token/failed read preserves document | Implemented |

## 6. Reuse and dependencies

Keep all SDP code in application. Reuse NavigationTree and document services;
no parser/runtime duplication, renderer subprocess registration or project-side
metadata mutation. Use private temporary output, never the source directory.
Automatic refresh uses an application-owned SdpWatch background metadata scanner.
It inspects only the selected SDP area (no symlink traversal), at most 20,000
entries/depth 32, with interruptible waits. A stable pair of samples coalesces
writes; continuous changes publish at least every two seconds. Errors disable
watching with a visible manual-Refresh diagnostic. Native event dispatch never
scans directories. Discovery is queued behind an in-flight generation; it never
replaces the document. Surviving canonical row identities restore expansion and
selection. Root changes discard the old graph; Refresh within a root preserves
its presentation state. Generated documents are snapshots and are not regenerated
automatically.

## 7. Verification

Initial evidence is recorded in [SN-001](../../../SDP/05--Implementation/SDP-Navigation/evidence/SN-001/README.md). Tests must exercise a real producer and
native tree/document delivery, with fake tools only for deterministic failures.
A compiled binary alone does not establish AT-074, AT-075 or independent review.

## 8. Status, risks and change impact

Implemented first increment, 2026-10-01. Protocol/producer and focused sanitizer
checks pass. SN-002 adds native GUI, graph bounds, automatic refresh and history
acceptance; independent review and the remaining M3 boundary checks are pending. Broad Mermaid grammar/render compatibility
remains #020; preserve source and report failures. Generated-document bundles use
window lifetime instead of a broker lease. Abrupt termination can leave private
temporary files; no recovery or global cleanup service is claimed.

SN-002 continues native acceptance and records the owner-authorized development
installation: [evidence](../../../SDP/05--Implementation/SDP-Navigation/evidence/SN-002/README.md).
