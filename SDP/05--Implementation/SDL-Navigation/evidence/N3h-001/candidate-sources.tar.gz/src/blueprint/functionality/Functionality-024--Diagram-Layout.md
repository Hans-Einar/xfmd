---
id: FUNC-024
kind: Functionality
audience: System
role: Service
owner: renderer
status: Implemented
scope: FirstRelease
requirements: UR-039, UR-040, UR-041, SR-021, SR-022, SR-023, SR-024
uses: none
---

# Functionality-024: Diagramlayout og tegnedata

Current dependency adoption: [N3b design](../../../SDP/04--Design/SDL-Navigation/Design.md).
The fork classifies Libavoid's invalid two-point diagonal no-route result as
NoSpace, enabling its existing single fresh-placement retry under the same
deadline and engine. It still rejects invalid geometry; frozen-position calls
do not gain a placement retry. No XFMD contract or call sequence changes.
Bootstrap consumes an exact commit/SHA-256 source archive, never a .deps patch.
The original VP07 regression must retain all 12 nodes and 18 edges through measured
layout and the shared native/PDF SVG path. Nested-group overlap remains open.

## 1. Hensikt og avgrensning

Renderer-tjeneste for grafplassering, rutegeometri og bibliotekgenerert SVG. Gjenbruker bibliotekets layout; har ingen dependency til interpreter og mottar aldri Mermaid-kilde.

## 2. Krav og akseptanse

UR-039–041, SR-021–023; AT-059–064. Se [design og kontrakter](../../../docs/design/mermaid-integration.md) og [krav](../../../xfmd_requirements.md).

## 3. Kontrakter og eierskap

IDiagramLayout::layout(DiagramModel, DiagramLayoutRequest, ITextMetrics&) → DiagramScene. Modellen og resultatet er XFMD-eide verdier. Rust-bridge rekonstruerer upstream Graph fra den rene modellen og bruker routed::compute med separat rutervalg. Layout inneholder tekstbokser/edge points; MermaidDiagramLayout dekoder inspeksjonsgeometri og ferdig SVG; DiagramPainter viser SVG gjennom librsvg/Cairo. DiagramPlacement lager én visual-run.

## 4. Atferd, tilstand og feil

Layout forberedes i worker. Tekstmåling skjer med samme fontgrunnlag som brødtekst/PDF; forkens measurements::with_measurements mater målte TextBlock-verdier til layout. Ingen oversettelse fra kildestreng til layout i denne tjenesten. Ingen SVG-rasterisering eller separate Pango-tekstobjekter for diagrametiketter. Ukjent form, NaN, ugyldig kant eller budsjettbrudd gir blokklokal feil.

## 5. Plumbing

| Steg | Hendelse / kaller | Kalt symbol | Kilde eller kontraktfil | Data / resultat | Feil / sideeffekt | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | `IDiagramLayout virtual dispatch` | `MermaidDiagramLayout::layout` | `src/renderer/diagram/MermaidDiagramLayout.cpp` | modell + font/request → immutable scene | checkpoint før/etter Rust | Implemented |
| 2 | `MermaidDiagramLayout::layout` | `DiagramTextLayout::measure` | `src/renderer/diagram/DiagramTextLayout.cpp` | etiketter → formede linjer og mål | samme ITextMetrics-port | Implemented |
| 3 | `MermaidDiagramLayout::layout` | `xfmd_diagram_layout_measured_v1` | `src/application/composition/mermaid/src/lib.rs` | ren graf + labelmål → LayoutResult | ingen parserkall/opaque parserhandle | Implemented |
| 4 | `xfmd_diagram_layout_measured_v1` | `layout` | `src/renderer/diagram/rust/src/lib.rs` | mapping → forkens routed::compute/render_svg → geometri og SVG | inputpayload 5 / model 3 / scene 3; maks 8 MiB | Implemented |
| 5 | `MermaidDiagramLayout::layout` | `Reader::finish` | `src/contracts/diagram/DiagramWire.h` | ferdig dekodet scene → kontrollert buffer | trailing data avvises; scene er XFMD-eid | Implemented |
| 6 | `BlockLayout::layout` | `DiagramPlacement::append` | `src/renderer/diagram/DiagramPlacement.cpp` | SVG-scene → én skalert visual-run | Approximate blokkanker, ingen sideklipping | Implemented |
| 7 | `layout` | `render_svg` | `src/renderer/diagram/rust/src/lib.rs` | eksisterende Layout → SVG-bytes | ingen ny parsing | Implemented |
| 8 | `layout` | `with_measurements` | `src/renderer/diagram/rust/src/lib.rs` | scoped TextBlock-mål og frist → valgt layout | TLS gjenopprettes også ved panic | Implemented |
| 9 | `layout` | `compute` | `src/renderer/diagram/rust/src/lib.rs` | graph + Engine + RoutingControl → RoutedLayout | Libavoid-feil blir synlig kildefallback | Implemented |
| 10 | `layout` | `render_svg_with_crossings` | `src/renderer/diagram/rust/src/lib.rs` | ferdige logiske ruter → valgfrie presentasjonshopp | ingen endring av rutepunkter | Implemented |
| 11 | `layout` | `add_label_leaders` | `src/renderer/diagram/rust/src/lib.rs` | ferdig SVG + immutable Layout → SVG med pekere og antall utelatelser | ingen ruteflytting; blokkerte pekere utelates med diagnostikk | Implemented |
| P36 | `layout` | `graph` | `src/renderer/diagram/rust/src/sequence.rs` | SequenceModel → dedikert sekvens-IR | bare validerte hendelser | Implemented |
| P36 | `layout` | `measurements::layout` | `src/renderer/diagram/rust/src/lib.rs` | målte sekvensetiketter → layout og SVG | kooperativ frist; ingen flowchart-ruting | Implemented |
| P38 | `xfmd_diagram_layout_measured_v1` | `layout_measured` | `src/renderer/diagram/rust/src/lib.rs` | typed model + lånt measurer → native layout/SVG | callback lever bare under synkront kall | Implemented |
| P38 | `layout_measured` | `graph` | `src/renderer/diagram/rust/src/semantic/mod.rs` | domenerekorder → riktig native DiagramKind | validerer kontrakt; ingen kildeparsing | Implemented |
| P38 | `text_metrics::measure` | `measureDiagramText` | `src/renderer/diagram/MermaidDiagramLayout.cpp` | UTF-8 + størrelse → ITextMetrics-mål | exceptions blir feilkode over C ABI | Implemented |
| P39–41 | `semantic::graph` | `populate` | `src/renderer/diagram/rust/src/semantic/c4.rs` | domain records → C4Data | validert modell, ingen parsing | Implemented |
| P39–41 | `semantic::graph` | `populate` | `src/renderer/diagram/rust/src/semantic/architecture.rs` | domain records → native portgeometri | validert modell, ingen parsing | Implemented |
| P39–41 | `semantic::graph` | `populate` | `src/renderer/diagram/rust/src/semantic/block.rs` | domain records → BlockDiagram | validert modell, ingen parsing | Implemented |
| P39–41 | `semantic::graph` | `populate` | `src/renderer/diagram/rust/src/semantic/planning.rs` | domain records → PacketField, TimelineEvent, GanttTask og journey | validert modell, ingen parsing | Implemented |
| P39–41 | `semantic::graph` | `populate` | `src/renderer/diagram/rust/src/semantic/charts.rs` | domain records → numeriske chart-data | validert modell, ingen parsing | Implemented |
| P39–41 | `semantic::graph` | `populate` | `src/renderer/diagram/rust/src/semantic/structures.rs` | domain records → tre, commit-graf og ZenUML events | validert modell, ingen parsing | Implemented |

## 6. Gjenbruk og avhengigheter

Konsumenter: FUNC-025, eksisterende MarkdownRenderer og PDF via vanlig frame. ITextMetrics er en ren kontrakt; Application injiserer implementasjonen. Bruker ikke parserens crate, kilde eller skjulte handle. Biblioteket eier SVG-former/piler/etiketter; Application eier SVG-leseren.

## 7. Verifikasjon

P30-regresjon: `docs/design/mermaid/traceability.mmd` (13 noder, 17 merkede
kanter) skal gi en full scene innen produksjonens eksisterende tidsbudsjett.
Undersøk og begrens kostbar ruteforbedring; ikke skjul feilen med lengre frist.

Implementert rettelse: tidskontrollen sampler klokken ved første og hvert
64. kontrollpunkt per layoutkall. Geometri og tidsbudsjett er uendret.
Regresjonen inngår også i MermaidPdfTest; TLS-testen dekker et helt
samplingsintervall slik at etterlatt deadline fortsatt ville blitt oppdaget.

DiagramLayoutTest dekker parserfri modell, begge brukerdiagrammer, nested grupper, fontmål, 128-noders kjede og tidsavbrudd med etterfølgende normal layout. DiagramReadingTest og MermaidPdfTest dekker skalering, merking og native tekst. Se [P29](../../../docs/evidence/P29.md).

P29 utvider fristkontrollene til indre løkker i rangering, kantpipeline, ruting
og etterbehandling etter at CI avdekket et langt intervall uten kontroll.
Tidsassertene gjelder fortsatt både produksjon og sanitizer-bygg.

## 8. Status, risiko og endringskonsekvenser

P31/P32: [Gjeldende SVG-/rutebeslutning](../../../docs/design/mermaid-svg-routing.md) erstatter tidligere native etiketttegning. Historiske tester nedenfor gjelder P25–P30; ny atferd er implementert; P31/P32-bevis beskriver faktisk verifikasjon.

[Rutestudien](../../../docs/design/mermaid-routing-study.md) dokumenterer
eksisterende sidevalg/A*/portfinjustering og foreslått felles kostnadspolicy.
En eventuell ny strategi utvikles i en separat bibliotekfork etter beslutning.
Planlagte symboler i studien er ikke del av dagens plumbing.

Implementert. Versjonsbundet patch leverer måleseam og kooperativ tidsgrense. P25–P30 bygget scene i adapteren og separate DrawRuns; dette erstattes i P31. Se P26-bevis og videre P28/P29-verifikasjon.

Akseptanse: AT-059, AT-060, AT-061, AT-062, AT-063, AT-064.

AT-065 dekkes av P32 og forkens rapport.

### P32: autoritativ ruting

Standardmotor er Libavoid; `XFMD_MERMAID_ROUTER=legacy` velger gammel motor
eksplisitt. Ukjente verdier avvises. `XFMD_MERMAID_CROSSING_JUMPS=1` slår på
presentasjonshopp. Valgene inngår i scenecachen. Resultatet eier diagnostikk
med faktisk motor og begrensninger; feil gir synlig kildefallback, ikke motorbytte.

Rust `layout` → `measurements::with_measurements` → `routed::compute` →
backendens samlede libavoid-transaksjon → målte etiketter/validering →
`render_svg` eller `render_svg_with_crossings` → payload 3. Ingen gamle
reparasjonspass endrer Libavoid-rutene. Native tidsavbrudd er kooperativt;
XFMDs dokumentkansellering kontrolleres før/etter FFI, mens native callback
kontrollerer fristen under transaksjonen.

Før native arbeid avviser adapteren over 256 kanter / 2048 kandidatporter.
DiagramLayoutTest skiller denne admission-feilen fra faktisk tidsavbrudd;
fristens nedre tidsassert gjelder bare tidsavbrudd. Etter begge feilveier
skal en vanlig modell fortsatt kunne rendres.

Et siste etikett-only-pass kan plassere på de ferdige rutene etter tredje
transaksjon; det kan ikke starte flere transaksjoner. Ubuntu/Pango-fixture
verifiserer dette i forken. Self-loop-endepunkter er distinkte punkter på
formgrensen; libavoid eier fortsatt ruting og segmentforskyvning.

Gjeldende P31/P32-verifikasjon: [samlet testbevis](../../../docs/evidence/P32.md).

### P33: målte, ombrutte kantetiketter

DiagramTextLayout::measure bryter kanttekst ved ordgrenser før måling.
MermaidDiagramLayout::layout serialiserer original nøkkel og faktiske linjer
i inputpayload 4; Rust layout bruker linjene direkte i TextBlock. Eksisterende
plumbing i kapittel 5 gjelder. Node-/gruppetitler prioriteres ved delt tekstnøkkel.
Se [policy og akseptanse](../../../docs/design/mermaid-label-wrap.md).

P33-verifikasjon: [før/etter-SVG og 8/8 relevante tester](../../../docs/evidence/P33.md).

### P34: beskyttet etikettilhørighet

SR-024 presiseres med en beskyttet sone mellom etikett og tilordnet segment.
Forkens labels::place prioriterer fri sone; labels::obstacles reserverer den
under eksisterende avgrensede pass; labels::validate avviser fremmede kanter
i sonen etter omruting. Implementert i fork-pin `0f23b7e`; verifikasjon dokumenteres i P34.
Ingen nye kall i XFMDs plumbing; endringen eies av bibliotekets rutepipeline.

P34-verifikasjon: [soneregresjoner og før/etter-SVG](../../../docs/evidence/P34.md).

### P35: synlige etikettpekere

Implementert: Rust layout kaller forkens add_label_leaders etter SVG-rendering.
Steget bruker ferdige ruter og mål, uten ny layout. Se
[geometri og feilvei](../../../docs/design/mermaid-label-leaders.md).

P35-verifikasjon: [SVG-sammenligning og testbevis](../../../docs/evidence/P35.md).

P36: [Typed dekning og Sequence 1](../../../mermaid_coverage.md)
utvider samme porter. Sequence 1 er Implemented; verifikasjon dokumenteres separat.

P36: [Faktiske kontroller og grenser](../../../docs/evidence/P36.md).

P37 Implemented: Sequence 2 bruker samme `parse`/`graph`-innganger, utvidede
ordnede hendelser, async-piltype og forkens `sequence_events::apply`.
Se [gjeldende dekning](../../../mermaid_coverage.md).

P38 Implemented: `semantic::graph` i `src/renderer/diagram/rust/src/semantic/`
oversetter domenerekorder til native bibliotektyper. `layout_measured` bruker
`measureDiagramText` via synkron ABI; forkens `with_measurer` låner konteksten.
Samme SVG-scene går til preview og PDF; ingen kildeparsing i renderer.

P39 Implemented: C4/Architecture/Block utvider SemanticDiagram med egne elementer,
grenser, portretninger og grid. Parserprofiler og native mapping ligger i
`semantic/{c4,architecture,block}.rs`; felles SVG/PDF-port gjenbrukes.
Se [profil og kontrakt](../../../docs/design/mermaid-architecture-authoring.md).

P40 Implemented: `semantic/planning.rs` parser og native adapter bevarer bitfelt,
perioder, tidsavhengighet og score. `semantic_planning.rs` i contracts validerer
typed records før layout. Native packet-geometri implementeres i forken.

P41 Implemented: chart/tree/git/ZenUML-profiler bruker egne records.
`semantic_charts.rs` validerer koordinater, hierarki og referencer; parserfiler
`charts`, `trees`, `git`, `zenuml` og rendererfiler `charts`, `structures`
bevarer semantikk uten original kilde over layoutgrensen.

### N3c — native use-case increment

[Use-case profile](../../../SDP/04--Design/SDL-Navigation/UseCase-Profile.md)
defines family23/records210–212 and acceptance. Implemented: strict usecase-beta parser
→ independently validated domain records → native fork UseCase graph/glyphs →
existing measured SVG/native/PDF path. No original source crosses the layout port.
The fork owns geometry and markers; XFMD owns syntax, semantic validation and
conversion. Producer overview selection is not delivered by this profile.

Plumbing: `src/interpreter/mermaid/rust/src/semantic/usecase.rs` emits element,
boundary and relation records; `src/contracts/diagram/rust/src/semantic_usecase.rs`
independently checks fields, identities, membership, endpoint kinds and labels.
`src/renderer/diagram/rust/src/semantic/usecase.rs` maps validated records to the
fork's UseCase graph. `compute_semantic_layout` routes real element endpoints with
Libavoid, including boundaries; actor ports attach to glyph strokes and avoid
captions. Unsupported syntax returns a diagnostic, never a partial diagram.
Source remains inside the interpreter; the existing SVG and native/PDF adapter
consumes measured output. See N3c-001 for candidate-specific verification.

### Paged height boundary — N3d real-model regression

A height-limited diagram must not exceed the printable height after floating-point
multiplication. Clamp the final DiagramPlacement height to that boundary and use
the same height for drawing, flow and maximum-run accounting. Preserve uniform
scaling within floating precision and unchanged continuous layout. Do not relax
PageBreaker's general oversized-line rejection. A 2065.6-point synthetic scene
reproduces the one-ULP overshoot on A4; also verify the real XFMD VP01 export.

### N3f measured-caption retry — Session0005 T009

[Selected repair boundary](../../../SDP/04--Design/SDL-Navigation/N3f-Routing.md)
keeps geometry in the renderer fork. routed::compute evaluates measured caption
space in its existing single expanded placement; route_positioned and strict
attachment validation retain their contracts. N3f-002 verifies the exact reported
fixture, original VP07 regression and native/PDF behavior; ChapterNavigation
ambiguity remains open under KB020.

### N3g caption-identity obstacles — Session0005 T010

[Repair boundary](../../../SDP/04--Design/SDL-Navigation/N3g-Routing.md) adds a
nearest-owner exclusion area to the fork's existing caption/attachment obstacles.
The radius uses actual route distance and existing tolerance/clearance; chamfered
corners preserve the Manhattan metric. Final strict validation and routing bounds
remain authoritative. No application or contract interface changes are required.
Candidate implementation/verification is recorded in N3g-001.

### N3h — full-size diagram reading

DiagramPlacement uses LayoutProfile.fullSizeDiagrams only in Continuous mode to keep scale 1 and extend contentWidth with a right gutter. Paged placement always fits. Scene identity and approximate source mapping are preserved.
See [selected design](../../../SDP/04--Design/SDL-Navigation/N3h-Reading.md).
