#pragma once
// Shared canonical model for producer/native overview regression checks.
inline constexpr const char* overviewFixture = R"sdl(language design-core version 0.5.
activity ABuild.
activity AIsolated.
activity APlan.
activity AVerify.
interface Api.
usecase Browse.
channel Bus.
contract ChannelBody.
contract ChannelEvents.
message ChannelNotice.
message ChannelUpdate.
field ChannelValue.
contract DataRecord.
field DataValue.
capability Delivery.
unit Desktop.
functionality Display.
scenario Example.
usecase Export.
actor Guest.
channel IdleBus.
usecase Isolated.
container Local.
dataset MemoryData.
feature Navigation.
mode Offline.
mode Online.
encoding PacketBig.
variant PacketBody.
field PacketFlag.
encoding PacketLittle.
field PacketNumber.
field PacketPayload.
database PersistentStore.
mode Quiet.
actor Reader.
container Remote.
interface SparePort.
unit Standalone.
dataset StoredData.
capability Unconnected.
contract UnusedShape.
database UnusedStore.
datagram WireFamily.
contract WireShape.
field WireValue.
variant WireVariant.
ABuild addresses Display.
ABuild delivers Navigation.
ABuild has implementation-status = implemented.
ABuild refines APlan.
APlan has implementation-status = planned.
AVerify depends-on ABuild.
AVerify has implementation-status = verified.
AVerify refines APlan.
Bus upholds ChannelEvents.
ChannelBody has completeness = closed.
ChannelBody has-field ChannelValue.
ChannelEvents has completeness = closed.
ChannelEvents permits ChannelNotice.
ChannelEvents permits ChannelUpdate.
ChannelNotice has message-kind = event.
ChannelNotice upholds ChannelBody.
ChannelUpdate has message-kind = event.
ChannelUpdate upholds ChannelBody.
ChannelValue has presence = required.
ChannelValue has value-type = text.
DataRecord has completeness = closed.
DataRecord has-field DataValue.
DataValue has presence = required.
DataValue has value-type = text.
Delivery requires Api in mode Offline.
Delivery requires SparePort in mode Online.
Desktop consumes Api.
Desktop holds MemoryData.
Desktop owns Display.
Desktop owns PersistentStore.
Desktop owns UnusedStore.
Desktop provides Delivery.
Desktop uses Bus as receiver of ChannelNotice in mode Offline.
Desktop uses Bus as sender of ChannelNotice in mode Online.
Desktop uses Bus as sender of ChannelUpdate in mode Online.
Display allocated-to Local in mode Offline.
Display allocated-to Remote in mode Online.
Display contributes-to Navigation.
Display has repeatability = deterministic.
Display has state-retention = stateful.
Display projects StoredData into WireFamily.
Display realizes Delivery.
Example has completeness = open.
Example runs-in Online.
Example step 1 sends ChannelNotice from Desktop to Remote via Bus.
IdleBus upholds ChannelEvents.
Local contains Desktop.
MemoryData upholds DataRecord.
Navigation supports Browse.
PacketBig encodes PacketBody.
PacketBig has bit-order = most-significant-first.
PacketBig has byte-order = big-endian.
PacketBig places PacketFlag at 0 bits 1.
PacketBig places PacketNumber at 1 bits 12.
PacketBig places PacketPayload at 13 bits 16.
PacketBody has-field PacketNumber.
PacketBody has-field PacketPayload.
PacketFlag has presence = required.
PacketFlag has value-type = boolean.
PacketLittle encodes PacketBody.
PacketLittle has bit-order = least-significant-first.
PacketLittle has byte-order = little-endian.
PacketLittle places PacketFlag at 0 bits 1.
PacketLittle places PacketNumber at 1 bits 12.
PacketLittle places PacketPayload at 13 bits 16.
PacketNumber has presence = required.
PacketNumber has value-type = signed.
PacketPayload has presence = required.
PacketPayload has value-type = bytes.
PersistentStore holds StoredData.
Reader pursues Browse.
Reader pursues Export.
Remote consumes Api.
Remote uses Bus as receiver of ChannelNotice in mode Online.
Remote uses Bus as receiver of ChannelUpdate in mode Online.
Remote uses Bus as sender of ChannelNotice in mode Offline.
StoredData upholds DataRecord.
UnusedShape has completeness = open.
WireFamily from StoredData.
WireFamily upholds WireShape.
WireShape defines PacketBody.
WireShape defines WireVariant.
WireShape has completeness = closed.
WireShape has-field PacketFlag.
WireValue has presence = optional.
WireValue has value-type = bytes.
WireVariant has-field WireValue.
)sdl";
