#pragma once
#define XFMD_BUILD_VERSION "0.6 sprint/009/phase/057-favorites:206+dirty"
