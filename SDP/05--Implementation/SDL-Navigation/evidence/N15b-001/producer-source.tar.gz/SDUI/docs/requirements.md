# SDUI — requirements and traceability

Updated 2026-09-22. Phase evidence: [G1–G3](../go/README.md), [G4–G6](../../SDL/go/README.md). The table follows the Go port; named Python baseline cases are frozen test data, not active tests.

| ID | Requirement | Owner / evidence | Status |
| --- | --- | --- | --- |
| SDUI-R01 | Named nested frames/groups | parser.Node; nested_groups_and_local_rows_preserved | Structure implemented; former Box profile replaced |
| SDUI-R02 | Horizontal elements/explicit rows | parser.rows; formatting_binds_before_separator | Implemented/tested |
| SDUI-R03 | Symbolic module/member references | ast.Reference; ported_example_bindings_and_instance_paths | Implemented; no external resolution |
| SDUI-R04 | Declarative setHandle | ast.Connection, validate; local_symbol_errors | Locally implemented |
| SDUI-R05 | Unambiguous names/instance paths | normalize; references_forward_reuse_and_cycles | Implemented; runtime handles in G3 |
| SDUI-R06 | Versioned EBNF/AST/source positions | raw_markdown_and_utf8_spans; version_is_exact_no_legacy | Implemented; no formal EBNF-equivalence proof |
| SDUI-R07 | Reject invalid profile semantics | formatting; shapes_ratio_and_relative_dimensions, widget_contracts | Local rules implemented |
| SDUI-R08 | Bounded work without source execution | bounded_work, truncations_and_malformed_inputs_are_structured | Implemented; no hard real-time guarantee |
| SDUI-R09 | Standalone AST without GUI/Mermaid | CLI; cli_source_protection_and_exit_codes | Implemented/tested |
| SDUI-R10 | Same normalized model from SDUI/Concept1 layout | Concept1 reference and Go normalization/layout | Reference structure verified; general React adapter outside profile |
| SDUI-R11 | Visible outer box, title, weights and widget layout in Fyne/SVG/Markdown | Go layout/svg/fynehost, G2 | Implemented/verified |
| SDUI-R12 | SDL object receives handle and updates text/value | Go runtime/bridge, G3/G4 | Implemented with action-core/typed Go functions |

Test names are abbreviated; source files contain full names. [Historical 0.1 verification](../evidence/verification.md) records the retired prototype. Semantic validation does not establish existence of external SDL files/functions.

## Delivery requirements and phase evidence

| ID | Requirement | Phase / evidence |
| --- | --- | --- |
| SDUI-R13 | General frames/regions, nested independently laid-out groups, reusable groups with instance paths | G1/G2 grammar/AST/group preservation, local separators, multilevel layout |
| SDUI-R14 | Markdown strings become source-mapped content widgets | G1/G2 multiline/escaping, width→height, content provider |
| SDUI-R15 | Ancestor-relative dimensions, x:y ratio, one driving scale axis with ratio, relative bounds/spacing, canonical arrows | G1/G2 reject px/two ratio axes; normalization, geometry oracles, overflow |
| SDUI-R16 | Typed runtime/backend ports with stable instances/atomic updates | G3 Go consumer, fake backend, real Fyne trials |
| SDUI-R17 | Coordinated geometry/clipping/printing for SVG, native controls and Markdown | G2 control maps, transforms, visual PDF/GUI checks |
| SDUI-R18 | Explicit SDL adapter port; labeled simulation | G3/G4 bidirectional correlation, revision conflicts, teardown; separate real SDL runtime |
| SDUI-R19 | One active frontend/API; port/remove legacy | G1-M3/G5-M4 target/import inventory, unsupported-version, no fallback |
| SDUI-R20 | Frame Markdown reuses agreed host profile/diagram coverage | G2/G3 profile matrix, links/labels, scroll/resources |
| SDUI-R21 | Per-component formatting before separators; absolute fonts without resize scaling | G1/G2/G3 suffixes on all component types, rows, stable fonts, rewrapping |

R13/R14/R15/R21 are verified through frontend, measured layout and native trials. R19 completed in G5-M4. R20 is bounded by markdown-provider.md: flowchart/graph, not all Mermaid types; scroll rejected. Existing XFMD BoxUI worktree remains separate; G6 adds a separate documentation consumer.

R10 initially means equivalent reference structure/geometry rules, not a general Concept1/React adapter. R11 revised on 2026-09-21: Fyne is the first interactive host, SVG-in-Markdown the documentation view. R12 uses real SDL action-core/bridge in G4; handwritten bucking domain remains a labeled simulation.

Owner clarification, 2026-09-20: R15 permits no source pixel width/height. Root references host layout area; children reference nearest ancestor. Direction-pair order preserves alignment, while formatting uses one canonical shape. Other lengths are also proposed relative. Clarification, 2026-09-21: `{16:9,<->}` fills width and derives height without contain fallback; header/footer stay inside ratio. Absolute fonts do not scale during resize. Shared units are logical DIP measured with Go Regular. Formatting follows components before separators; comma continues horizontally, semicolon starts below the preceding row. Canonical corners: ^<, >^, v<, >v; right-center: ->.

**SDUI-R22:** static GUI dump from shared model with raw Markdown and omitted Mermaid fences. Implemented/tested in go/presentation. Interactive console is planned in the [TUI direction](concept1-console.md).

**SDUI-R23:** static Markdown dump from the same model, with layout overview/renderable content. Preserve tables/lists/code, label widgets static, omit Mermaid as in text dumps. No interaction/new parser. Content shows reading order/nesting, not exact GUI geometry.

**SDUI-R24:** bounded SDUI prototype library draws static SVG button/input widgets in Markdown. The same descriptions may demonstrate editing, pressed/focused appearance and printing current values in local HTML. No SDL calls, network, FOX dependency or new parser. Distinguish prototype placement/demo state from later shared layout/runtime. Delivered as a bounded trial; [scope](prototype-widgets.md), [test/browser evidence](../evidence/prototype-widgets/README.md).

**SDUI-R25:** parse/validate/publish source changes without closing UI windows. Retain last valid model on errors and compatible value/focus on reload; reject stale events. SDL state needs migration/reset rules. Go-function changes rebuild/restart. Implemented/verified G3/G4.

**SDUI-R26:** Go generation shares development models/runtime and separates generated code from handwritten domain functions. Unknown/incomplete SDL execution semantics produce diagnostics. Implemented/verified G5.

## XFMD combined-preview refinement — KB-SDUI-005, 2026-10-07

Generate a structural composition diagram and provenance table beside the existing
static text render. Retain hidden/reused instance identity, effective layout,
symbolic bindings and exact declaration/use spans. Host preflight must distinguish
local prototype readiness from SDL connectivity and reject stale source revisions.
A consumer may bundle the SDUI-owned tools; parser/runtime remain host-independent.

## Selected widget inventory — KB-SDUI-003, Session0010

**SDUI-R27:** deliver the card's tree/list and scroll
viewports, tabs/splits, button/toggle commands, menu/context/dialog, checkbox,
slider/select/numeric input, extended single-line and basic multiline input, plus
explicit SVG/Markdown provider and fallback contracts. Preserve typed identity,
draft atomicity, programmatic/user-event distinction and reload/disposal guards.
Full editors, component source sets and native XFMD parity are outside this scope.

**SDUI-R28:** separate source/profile, layout, provider
and native capabilities; prepare all required bindings before connected activation.
An unbound prototype is not connected readiness. Unsupported exports reject or use
an explicitly selected labelled static fallback. Parser success is insufficient.

The [reviewed design](../../SDP/04--Design/SDUI/Widgets/Design.md),
[acceptance matrix](../../SDP/04--Design/SDUI/Widgets/Acceptance.md) and
[implementation plan](../../SDP/05--Implementation/SDUI/Widgets/Plan.md) define
staged delivery. Source 0.3 is selected for new syntax; current implemented 0.2
and frozen historical fixtures retain their meaning. Native behavior and matching
consumer package evidence are required before declaring the inventory delivered.

WCI1 delivers the bounded tree/list/scroll portion of R27 and guarded native
publication for R28; see [WCI1 evidence](../../SDP/05--Implementation/SDUI/Widgets/Evidence-WCI1.md).
Remaining widget families and consumer packaging stay open under PLAN-SDP-0022.


WCI2-M1 delivers tabs/splits with retained drafts, focus and measured geometry;
see [pane evidence](../../SDP/05--Implementation/SDUI/Widgets/Evidence-WCI2-M1.md).
WCI2-M2 delivers shared commands, menus and composed modal/nonmodal surfaces;
[verified evidence](../../SDP/05--Implementation/SDUI/Widgets/Evidence-WCI2-M2.md)
records 118 native checks and independent approval: exactly-once dispatch,
stale-context refusal, truthful domain outcomes, draft-preserving rejection and
one terminal result for each of 26 published openings. At that command milestone, WCI3/WCI4 were still pending; their delivery follows below.

WCI3-M1 implements the checkbox/slider/select/number portion of R27 with exact typed
values, invalid-draft feedback, stable option identity and atomic mixed forms under
R28 publication guards. [Reviewed scalar evidence](../../SDP/05--Implementation/SDUI/Widgets/Evidence-WCI3-M1.md)
proves pointer/keyboard Change versus Commit, visible slider proposal feedback,
readonly/programmatic behavior, invalid-draft refusal, stale-result rejection,
child Commit versus form Cancel and truthful post-domain failure through 113 native
checks and passing suites. At that scalar milestone, extended text/IME remained WCI3-M2 work.

WCI3-M2 implements opt-in extended single-line and basic multiline input for R27:
explicit Change/Commit, required validation, read-only selection/copy, placeholder,
Unicode clipboard, native undo/redo and internal scrolling under R28 publication
guards. Native typing/IME, failed edits, reload and same/different-byte history
policies require exact-candidate evidence. A rejected native edit may reset that
Entry editing history while restoring authoritative text; failed Commit/reload
retain history. [Reviewed M2 evidence](../../SDP/05--Implementation/SDUI/Widgets/Evidence-WCI3-M2.md) closes the bounded text inventory with 92 native checks, actual IME, shared-command receiver correction and affected suites. At that text milestone, WCI4 consumer/provider preparation remained open; its current status follows below.

WCI4 implements explicit per-instance SVG/Markdown preview identity, immutable
preparation and truthful supported/fallback/unsupported outcomes for R27/R28.
Required evidence includes finite closed-subset resource admission, independent
policies for identical Markdown, copied buffers, no renderer calls after preparation,
shared fit/clip/caption/status geometry and exact native owner teardown. Public
unsupported exports must preserve the previous artifact. Matching producer/private
helpers and connected application examples need actual protocol/native/IME evidence.
The linked plan and acceptance matrix own current delivery status; no release,
installed-consumer upgrade, dark-theme contrast or OS screen-reader support is
inferred from the implementation. Separate fidelity work remains KB-SDUI-004.
