package sdptool

import (
	"context"
	"fmt"
	"github.com/Hans-Einar/SDP/SDPTool/blueprints"
	"github.com/Hans-Einar/SDP/SDPTool/blueprintstate"
	"github.com/Hans-Einar/SDP/SDPTool/model"
	"github.com/Hans-Einar/SDP/SDPTool/presentation"
	"io"
	"strings"
)

func modelCommand(ctx context.Context, area string, args []string, out, errs io.Writer, jsonMode bool) int {
	var r model.Result
	var e error
	bad := func() int {
		return reportMode(errs, failure("arguments", fmt.Errorf("invalid model command; use sdptool model help")), jsonMode)
	}
	if len(args) == 1 && (args[0] == "help" || args[0] == "--help") {
		_, err := io.WriteString(out, modelHelp)
		if err != nil {
			return reportMode(errs, err, jsonMode)
		}
		return 0
	}
	if len(args) == 0 {
		return bad()
	}
	switch args[0] {
	case "assignment":
		if len(args) == 2 && args[1] == "list" {
			value, _, err := performAssignmentList(ctx, actionContext{Area: area}, noActionParameters{})
			if err != nil {
				return reportMode(errs, failure("assignment", err), jsonMode)
			}
			if err = presentation.Default().Write(out, value, jsonMode); err != nil {
				return reportMode(errs, err, jsonMode)
			}
			return 0
		}
		if len(args) != 8 || args[1] != "apply" || args[2] != "--request" || args[4] != "--as" || args[6] != "--authority" {
			return bad()
		}
		req, err := blueprints.LoadAssignmentRequest(args[3])
		if err != nil {
			return reportMode(errs, failure("assignment", err), jsonMode)
		}
		result, _, err := performAssignmentApply(ctx, actionContext{Area: area, Caller: ActionCaller{Principal: blueprintstate.Principal{Actor: args[5], Authority: args[7]}}}, ApplyAssignmentInput{Request: req})
		if err != nil {
			return reportMode(errs, failure("assignment", err), jsonMode)
		}
		if err = presentation.Default().Write(out, result, jsonMode); err != nil {
			return reportMode(errs, err, jsonMode)
		}
		return 0
	case "assess":
		if len(args) != 6 || args[1] != "blueprint" || args[2] != "--bundle" || args[4] != "--evidence" {
			return bad()
		}
		assessment, code, err := performAssess(ctx, actionContext{}, AssessActionInput{Bundle: args[3], Evidence: args[5]})
		if err != nil {
			return reportMode(errs, failure("blueprint-evidence", err), jsonMode)
		}
		if err = presentation.Default().Write(out, assessment, jsonMode); err != nil {
			return reportMode(errs, err, jsonMode)
		}
		return code
	case "snapshot":
		if len(args) != 2 {
			return bad()
		}
		view, err := model.Snapshot(area, args[1])
		if err != nil {
			return reportMode(errs, err, jsonMode)
		}
		if err = presentation.Default().Write(out, view, jsonMode); err != nil {
			return reportMode(errs, err, jsonMode)
		}
		return 0
	case "merge":
		if len(args) != 4 || args[2] != "into" {
			return bad()
		}
		r, e = model.Merge(area, args[1], args[3], "")
	case "commit":
		if len(args) != 4 && len(args) != 5 {
			return bad()
		}
		if args[2] != "--message" {
			return bad()
		}
		resolved := len(args) == 5 && args[4] == "--resolved"
		if len(args) == 5 && !resolved {
			return bad()
		}
		r, e = model.Commit(area, args[1], args[3], resolved)
	case "restore":
		if len(args) != 4 || args[2] != "to" || !strings.HasPrefix(args[3], "commit:") {
			return bad()
		}
		r, e = model.Restore(area, args[1], strings.TrimPrefix(args[3], "commit:"))
	case "recover":
		if len(args) != 3 {
			return bad()
		}
		r, e = model.Recover(area, args[1], args[2])
	case "status", "history":
		if len(args) != 2 {
			return bad()
		}
		r, e = model.Status(area, args[1])
		r.Operation = args[0]
	case "create":
		if len(args) > 1 && args[1] == "blueprint" {
			if len(args) != 12 || args[2] != "from" || args[4] != "to" {
				return bad()
			}
			opts := map[string]string{}
			for i := 6; i < len(args); i += 2 {
				if args[i] != "--entry" && args[i] != "--task" && args[i] != "--output" && args[i] != "--catalogue" {
					return bad()
				}
				if _, ok := opts[args[i]]; ok {
					return bad()
				}
				opts[args[i]] = args[i+1]
			}
			b, _, err := performGenerate(ctx, actionContext{}, GenerateActionInput{ModelArea: area, From: args[3], To: args[5], Entry: opts["--entry"], Task: opts["--task"], Output: opts["--output"], Catalogue: opts["--catalogue"]})
			if err != nil {
				return reportMode(errs, failure("blueprint", err), jsonMode)
			}
			if err = presentation.Default().Write(out, b, jsonMode); err != nil {
				return reportMode(errs, err, jsonMode)
			}
			return 0
		}
		if len(args) < 2 {
			return bad()
		}
		target := strings.SplitN(args[1], ":", 2)
		if len(target) != 2 {
			return bad()
		}
		if target[0] != "work" {
			if len(args) < 4 || args[2] != "from" {
				return bad()
			}
			evidence := ""
			code := ""
			checks := ""
			if (len(args)-4)%2 != 0 {
				return bad()
			}
			seen := map[string]bool{}
			for i := 4; i < len(args); i += 2 {
				if seen[args[i]] {
					return bad()
				}
				seen[args[i]] = true
				switch args[i] {
				case "--evidence":
					evidence = args[i+1]
				case "--code-digest":
					code = args[i+1]
				case "--checks":
					checks = args[i+1]
				default:
					return bad()
				}
			}
			if evidence == "verified" {
				if code == "" || checks == "" {
					return bad()
				}
				evidence = "verified:" + code + ":" + checks
			} else if code != "" || checks != "" {
				return bad()
			}
			r, e = model.Freeze(area, target[0], target[1], args[3], evidence)
			break
		}
		initial := false
		from := ""
		switch {
		case len(args) == 2:
		case len(args) == 3 && args[2] == "--initial":
			initial = true
		case len(args) == 5 && args[2] == "from":
			r, e = model.Merge(area, args[4], args[3], target[1])
			break
		case len(args) == 4 && args[2] == "from":
			from = args[3]
		default:
			return bad()
		}
		if len(args) != 5 {
			r, e = model.CreateWork(area, target[1], from, initial)
		}
	default:
		return bad()
	}
	if e != nil {
		if me, ok := e.(*model.Error); ok {
			return reportMode(errs, failure(me.Code, fmt.Errorf("%s", me.Detail)), jsonMode)
		}
		return reportMode(errs, e, jsonMode)
	}
	if e = presentation.Default().Write(out, r, jsonMode); e != nil {
		return reportMode(errs, e, jsonMode)
	}
	return 0
}

const modelHelp = `Usage: sdptool [MODEL-AREA] model ACTION [--json]
  create work:NAME [--initial | from release:VERSION]
  create work:COMBINED from work:A work:B
  commit work:NAME --message TEXT [--resolved]
  restore work:NAME to commit:00001
  merge work:SOURCE into work:TARGET
  create candidate:NAME from work:NAME
  create proposal:NAME from work:NAME
  create release:VERSION from candidate:NAME --evidence model-only
    or --evidence verified --code-digest SHA256 --checks REFERENCE
  create blueprint from kind:NAME to kind:NAME --entry System.design --task TASK.json --output DIRECTORY (or --catalogue SDP/Blueprints)
  assess blueprint --bundle RETAINED-DIR --evidence EVIDENCE.json
  assignment list
  assignment apply --request REQUEST.json --as ACTOR --authority controller|assignee|reviewer
  status|history|snapshot kind:NAME
  recover OPERATION-UUID resume|abort
MODEL-AREA is the directory containing artifact folders; no Git or SDP install required.
Assignment commands take the SDP area, with canonical ProjectManagement/Traceability records.
The local CLI is a trusted controller boundary; --as is attribution, not authentication.
WORK snapshots are preliminary. Blueprints are diagnostic previews, not executable assignments.
`
