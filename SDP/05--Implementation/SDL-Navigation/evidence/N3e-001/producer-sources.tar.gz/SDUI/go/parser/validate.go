package parser

import "strings"

type widgetSchema struct {
	position string
	fields   map[string]string
	required string
}

var widgets = map[string]widgetSchema{
	"button": {"label", map[string]string{"label": "string", "callback": "reference"}, "label"},
	"input":  {"text", map[string]string{"text": "string", "value": "string", "callback": "reference"}, "text"},
	"svg":    {"source", map[string]string{"source": "reference", "label": "string"}, "source"},
}

func schemaFor(profile, kind string) (widgetSchema, bool) {
	if profile == "sdui/0.3" {
		if schema, ok := previews[kind]; ok {
			return schema, true
		}
		if kind == "input" {
			return input03, true
		}
		if schema, ok := scalars[kind]; ok {
			return schema, true
		}
		if schema, ok := interactions[kind]; ok {
			return schema, true
		}
		if schema, ok := panes[kind]; ok {
			return schema, true
		}
	}
	if profile == "sdui/0.3" && (kind == "tree" || kind == "list") {
		return widgetSchema{"label", map[string]string{"label": "string", "callback": "reference"}, "label"}, true
	}
	s, ok := widgets[kind]
	return s, ok
}

func widgetArguments(n *Node, profile string) map[string]any {
	schema, _ := schemaFor(profile, val(n.Widget))
	out := map[string]any{}
	for _, a := range n.Arguments {
		k := val(a.Name)
		if a.Name == nil {
			k = schema.position
		}
		out[k] = a.Value
	}
	if profile == "sdui/0.3" && val(n.Widget) == "split" {
		for key, value := range map[string]Literal{
			"proportion":  {Kind: "number", Value: float64(.5), Span: n.Span},
			"minFirst":    {Kind: "number", Value: float64(0), Span: n.Span},
			"minSecond":   {Kind: "number", Value: float64(0), Span: n.Span},
			"collapsible": {Kind: "boolean", Value: true, Span: n.Span},
		} {
			if _, exists := out[key]; !exists {
				out[key] = value
			}
		}
	}
	return out
}
func validateWidget(n *Node, modules map[string]bool, profile string) {
	schema, ok := schemaFor(profile, val(n.Widget))
	if !ok {
		fail("widget-kind", "Unsupported widget "+val(n.Widget), n.Span)
	}
	seen := map[string]bool{}
	for _, a := range n.Arguments {
		if a.Name == nil && len(seen) > 0 {
			fail("argument-order", "Only one positional argument before named arguments", a.Span)
		}
		k := val(a.Name)
		if a.Name == nil {
			k = schema.position
		}
		if seen[k] {
			fail("duplicate-argument", "Duplicate "+k, a.Span)
		}
		expected, ok := schema.fields[k]
		if !ok {
			fail("widget-property", "Unknown widget property "+k, a.Span)
		}
		switch v := a.Value.(type) {
		case Reference:
			if expected != "reference" {
				fail("argument-type", "Expected "+expected, a.Span)
			}
			if !modules[v.Module] {
				fail("unknown-module", "Unknown module "+v.Module, v.Span)
			}
		case Literal:
			if v.Kind != expected {
				fail("argument-type", "Expected "+expected, a.Span)
			}
			if val(n.Widget) == "tree" || val(n.Widget) == "list" {
				label, ok := v.Value.(string)
				if !ok || strings.TrimSpace(label) == "" {
					fail("collection-label", "Collection requires a nonempty accessible label", a.Span)
				}
			}
		default:
			fail("argument-type", "Invalid argument", a.Span)
		}
		seen[k] = true
	}
	if seen["callback"] && n.Name == nil {
		fail("widget-name", "A callback requires a named widget", n.Span)
	}
	if schema.required != "" && !seen[schema.required] {
		fail("missing-argument", "Missing "+schema.required, n.Span)
	}
}
func validateLocal(d *Document) {
	if d == nil {
		fail("document", "Nil document", Span{})
	}
	if _, err := ASTFormat(d.Profile); err != nil {
		fail("profile", "Unsupported document profile "+d.Profile, d.Span)
	}
	modules := map[string]bool{}
	definitions := map[string]Definition{}
	for _, r := range d.References {
		if modules[r.Alias] {
			fail("duplicate-module", "Duplicate module", r.Span)
		}
		bad := r.Path == ""
		for _, c := range r.Path {
			bad = bad || c < 32 || c == 127
		}
		if bad {
			fail("module-path", "Invalid module path", r.Span)
		}
		modules[r.Alias] = true
	}
	for _, def := range d.Definitions {
		if _, ok := definitions[def.Name]; ok || modules[def.Name] {
			fail("duplicate-definition", "Ambiguous definition "+def.Name, def.Span)
		}
		definitions[def.Name] = def
	}
	deps := map[string][]string{}
	for _, def := range d.Definitions {
		names := map[string]bool{}
		var visit func(*Node)
		visit = func(n *Node) {
			name := val(n.Name)
			if name == "" && n.Kind == "use" {
				name = val(n.Target)
			}
			if name != "" {
				if names[name] {
					fail("duplicate-node", "Duplicate name "+name, n.Span)
				}
				names[name] = true
			}
			if n.Kind == "use" {
				if _, ok := definitions[val(n.Target)]; !ok {
					fail("unknown-definition", "Unknown component "+val(n.Target), n.Span)
				}
				deps[def.Name] = append(deps[def.Name], val(n.Target))
			} else {
				formatting(n, sourceKind(n, d.Profile), len(n.Rows))
			}
			if n.Variant != nil && (n.Kind != "frame" || !member(*n.Variant, "b box")) {
				fail("variant", "Only frame variants box/b supported", n.Span)
			}
			if n.Kind == "widget" || n.Kind == "composition" {
				decl := n
				if d.Profile == "sdui/0.3" && n == def.Root && (val(n.Widget) == "input" && extendedInputArguments(widgetArguments(n, d.Profile)) || scalarKind(val(n.Widget)) || isInteractionNode(&Instance{Profile: d.Profile, Kind: n.Kind, Widget: val(n.Widget), Arguments: widgetArguments(n, d.Profile)})) {
					copy := *n
					copy.Name = str(def.Name)
					decl = &copy
				}
				validateWidget(decl, modules, d.Profile)
				validatePaneSource(n, d.Profile)
				validateInteractionSource(decl, d.Profile)
				validatePreviewSource(n, d.Profile)
				if d.Profile == "sdui/0.3" && val(n.Widget) == "input" {
					if len(n.Rows) != 0 {
						fail("input-argument", "Input controls are leaves", n.Span)
					}
					if _, err := InputOptions(&Instance{Profile: d.Profile, Kind: n.Kind, Widget: "input", Arguments: widgetArguments(n, d.Profile), Span: n.Span}); err != nil {
						panic(err)
					}
				}
				if d.Profile == "sdui/0.3" && scalarKind(val(n.Widget)) {
					if len(n.Rows) != 0 {
						fail("value-body", "Scalar controls are leaves", n.Span)
					}
					validateScalar(&Instance{Profile: d.Profile, Kind: n.Kind, Widget: val(n.Widget), Arguments: widgetArguments(n, d.Profile), Span: n.Span})
				}
			}
			roles := map[string]bool{}
			body := false
			for _, row := range n.Rows {
				for _, child := range row.Items {
					if n.Kind == "group" && child.Kind == "frame" {
						fail("group-content", "Frame in widget group", child.Span)
					}
					if child.Role != nil {
						if roles[*child.Role] {
							fail("duplicate-region", "Duplicate region", child.Span)
						}
						roles[*child.Role] = true
					} else {
						body = true
					}
					visit(child)
				}
			}
			if roles["body"] && body {
				fail("body-conflict", "Explicit and implicit body cannot mix", n.Span)
			}
		}
		visit(def.Root)
	}
	done := map[string]bool{}
	stack := map[string]bool{}
	var cycle func(string, int)
	cycle = func(name string, depth int) {
		if stack[name] {
			fail("reference-cycle", "Recursive reference "+name, definitions[name].Span)
		}
		if depth >= 64 {
			fail("depth-limit", "Reference chain exceeds 64", definitions[name].Span)
		}
		if done[name] {
			return
		}
		stack[name] = true
		for _, child := range deps[name] {
			cycle(child, depth+1)
		}
		delete(stack, name)
		done[name] = true
	}
	for _, def := range d.Definitions {
		cycle(def.Name, 0)
	}
}
func validateConnections(d *Document, roots map[string]*Instance) {
	modules := map[string]bool{}
	for _, r := range d.References {
		modules[r.Alias] = true
	}
	paths := map[string]bool{}
	var visit func(*Instance)
	visit = func(n *Instance) {
		parts := strings.Split(n.Path, "/")
		if n.Kind == "widget" && !strings.HasPrefix(parts[len(parts)-1], "$") {
			public := []string{}
			for _, p := range parts {
				if !strings.HasPrefix(p, "$") {
					public = append(public, p)
				}
			}
			path := strings.Join(public, "/")
			if paths[path] {
				fail("duplicate-instance", "Ambiguous path "+path, n.Span)
			}
			paths[path] = true
		}
		for _, row := range n.Rows {
			for _, child := range row {
				visit(child)
			}
		}
		for _, reg := range n.Regions {
			visit(reg.Node)
		}
	}
	for _, def := range d.Definitions {
		visit(roots[def.Name])
	}
	objects, targets := map[string]bool{}, map[string]bool{}
	for _, con := range d.Connections {
		if !modules[con.Module] {
			fail("unknown-module", "Unknown module "+con.Module, con.Span)
		}
		if roots[con.Definition] == nil {
			fail("unknown-definition", "Unknown definition", con.Span)
		}
		target := con.Definition + "/" + strings.Join(con.Path, "/")
		if !paths[target] {
			fail("unknown-widget", "Unknown widget "+target, con.Span)
		}
		obj := con.Module + "." + con.Object
		if objects[obj] || targets[target] {
			fail("duplicate-connection", "One connection per object/widget", con.Span)
		}
		objects[obj] = true
		targets[target] = true
	}
}

// Validate checks local semantics including bounded instance expansion.
func Validate(d *Document) error { _, err := Normalize(d); return err }
