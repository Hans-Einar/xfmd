module github.com/Hans-Einar/SDP/SDPTool

go 1.26.0

require (
	github.com/Hans-Einar/SDP/SDUI/go v0.0.0
	github.com/Hans-Einar/SDP/SystemDesignLanguage/go v0.0.0
	gopkg.in/yaml.v3 v3.0.1
)

require (
	github.com/google/jsonschema-go v0.4.3 // indirect
	github.com/segmentio/asm v1.1.3 // indirect
	github.com/segmentio/encoding v0.5.4 // indirect
	github.com/yosida95/uritemplate/v3 v3.0.2 // indirect
	golang.org/x/oauth2 v0.35.0 // indirect
	golang.org/x/sync v0.23.0 // indirect
	golang.org/x/sys v0.48.0 // indirect
	golang.org/x/text v0.42.0 // indirect
	golang.org/x/time v0.15.0 // indirect
)

replace github.com/Hans-Einar/SDP/SystemDesignLanguage/go => ../SDL/go

replace github.com/Hans-Einar/SDP/SDUI/go => ../SDUI/go

require (
	github.com/Hans-Einar/SDP/SDPTool/bootstrap v0.0.0
	github.com/modelcontextprotocol/go-sdk v1.8.0
)

replace github.com/Hans-Einar/SDP/SDPTool/bootstrap => ./bootstrap
