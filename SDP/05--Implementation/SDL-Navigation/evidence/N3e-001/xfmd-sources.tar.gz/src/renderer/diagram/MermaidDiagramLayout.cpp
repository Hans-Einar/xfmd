#include "MermaidDiagramLayout.h"
#include "DiagramTextLayout.h"
#include "contracts/diagram/DiagramLimits.h"
#include "contracts/diagram/DiagramWire.h"
#include <algorithm>
#include <cmath>
namespace xfmd {
namespace {
uint32_t measureDiagramText(void* context, const uint8_t* data, uint64_t length, double size,
                            double* width, double* height) noexcept {
  try {
    if (!context || !data || length > 65536 || !width || !height || !std::isfinite(size) ||
        size <= 0 || size > 512)
      return 1;
    FontSpec font;
    font.points = std::max(1, int(std::round(size * .75)));
    auto measured = static_cast<ITextMetrics*>(context)->measure(
        {reinterpret_cast<const char*>(data), std::size_t(length)}, font);
    auto scale = size / font.points;
    *width = measured.width * scale;
    *height = measured.height * scale;
    return 0;
  } catch (...) {
    return 1;
  }
}
} // namespace

std::shared_ptr<const DiagramScene>
MermaidDiagramLayout::layout(const DiagramModel& model, const DiagramLayoutRequest& request,
                             ITextMetrics& metrics) {
  auto checkpoint = [&] {
    if (request.cancelled && request.cancelled())
      throw Error(ErrorCode::Layout, "Diagram preparation cancelled");
  };
  checkpoint();
  auto texts = DiagramTextLayout::measure(model, metrics);
  diagramWire::Writer w;
  w.integer(5); // Versioned layout payload; C ABI envelope remains v1.
  w.model(model);
  w.integer(diagramLayoutBudgetMilliseconds);
  w.integer(texts.size());
  for (const auto& pair : texts) {
    w.text(pair.first);
    w.number(pair.second.width / .75);
    w.number(pair.second.height / .75);
    w.integer(pair.second.lines.size());
    for (const auto& line : pair.second.lines)
      w.text(line.text);
  }
  diagramWire::ResultOwner result(xfmd_diagram_layout_measured_v1(1, w.data.data(), w.data.size(),
                                                                  &metrics, measureDiagramText),
                                  xfmd_diagram_layout_free_v1);
  checkpoint();
  diagramWire::Reader r(result.result);
  if (r.integer() != 3)
    throw Error(ErrorCode::Layout, "Unsupported diagram layout payload");
  auto scene = std::make_shared<DiagramScene>();
  scene->fonts = metrics.fontSetId();
  scene->width = r.number() * .75;
  scene->height = r.number() * .75;
  if (scene->width <= 0 || scene->height <= 0)
    throw Error(ErrorCode::Layout, "Empty diagram layout");
  auto rect = [&] {
    double x = r.number() * .75, y = r.number() * .75, w = r.number() * .75, h = r.number() * .75;
    if (w <= 0 || h <= 0)
      throw Error(ErrorCode::Layout, "Invalid diagram box");
    return Rect{x, y, w, h};
  };
  auto label = [&](const std::string& text, double x, double y, bool background) {
    const auto& measured = texts.at(text);
    for (auto line : measured.lines) {
      line.origin.x = x - line.extent.width / 2;
      line.origin.y += y - measured.height / 2;
      line.background = background;
      scene->labels.push_back(std::move(line));
    }
  };
  const auto count = r.count(128);
  if (count != model.nodes.size())
    throw Error(ErrorCode::Layout, "Diagram node mismatch");
  for (unsigned i = 0; i < count; ++i)
    scene->nodes.push_back({rect(), model.nodes[i].shape});
  const auto groups = r.count(32);
  if (groups != model.groups.size())
    throw Error(ErrorCode::Layout, "Diagram group mismatch");
  // Layout may reorder independent clusters. Match their stable identities,
  // retaining model order in the inspection scene and rejecting duplicates.
  scene->groups.resize(groups);
  std::vector<double> groupHeights(groups);
  std::vector<bool> seen(groups, false);
  for (unsigned i = 0; i < groups; ++i) {
    auto id = r.text();
    auto box = rect();
    auto height = r.number() * .75;
    auto group = std::find_if(model.groups.begin(), model.groups.end(),
                              [&](const auto& value) { return value.id == id; });
    if (group == model.groups.end())
      throw Error(ErrorCode::Layout, "Unknown diagram group identity");
    const auto index = std::size_t(group - model.groups.begin());
    if (seen[index])
      throw Error(ErrorCode::Layout, "Duplicate diagram group identity");
    seen[index] = true;
    scene->groups[index] = box;
    groupHeights[index] = height;
  }
  for (unsigned i = 0; i < groups; ++i) {
    const auto& box = scene->groups[i];
    label(model.groups[i].label, box.x + box.width / 2, box.y + groupHeights[i] / 2 + 6, false);
  }
  for (unsigned i = 0; i < count; ++i) {
    const auto& box = scene->nodes[i].bounds;
    label(model.nodes[i].label, box.x + box.width / 2, box.y + box.height / 2, false);
  }
  const auto edges = r.count(512);
  if (edges != model.edges.size())
    throw Error(ErrorCode::Layout, "Diagram edge mismatch");
  for (unsigned i = 0; i < edges; ++i) {
    DiagramEdgePath path;
    path.start = model.edges[i].arrowStart;
    path.end = model.edges[i].arrowEnd;
    path.style = model.edges[i].style;
    auto points = r.count(65536);
    if (points < 2)
      throw Error(ErrorCode::Layout, "Empty diagram edge");
    for (unsigned j = 0; j < points; ++j) {
      double x = r.number() * .75, y = r.number() * .75;
      path.points.push_back({x, y});
    }
    scene->edges.push_back(std::move(path));
    double x = r.number() * .75, y = r.number() * .75;
    if (!model.edges[i].label.empty())
      label(model.edges[i].label, x, y, true);
  }
  scene->svg = r.text(8 * 1024 * 1024);
  if (scene->svg.rfind("<svg", 0) != 0)
    throw Error(ErrorCode::Layout, "Missing diagram SVG");
  scene->diagnostics = r.text();
  r.finish();
  scene->bytes = result.result.size;
  for (const auto& l : scene->labels)
    scene->bytes += sizeof(l) + l.text.size() * 128;
  if (scene->bytes > 8 * 1024 * 1024)
    throw Error(ErrorCode::TooLarge, "Diagram scene exceeds budget");
  return scene;
}
} // namespace xfmd
